import { CHAT, logger } from '#core'
import { downloadMediaMessage } from '@laminaris/baileys'
import sharp from 'sharp'
import { buildPdf, PAGE_SIZE_NAMES } from './lib/pdf.js'
import { MAX_BYTES } from './lib/formats.js'

const WINDOW_MS = 90 * 1000
const MAX_IMAGES = 60
const MAX_PAGES_DIM = 20000

// chatKey -> [{ at, key, msg, sender }]
const recent = new Map()

function prune(chatKey, sender = null, now = Date.now()) {
  const list = recent.get(chatKey)
  if (!list) return []
  const kept = list
    .filter((e) => now - e.at <= WINDOW_MS)
    .filter((e) => !sender || e.sender === sender)
    .slice(-MAX_IMAGES)
  if (kept.length) recent.set(chatKey, kept)
  else recent.delete(chatKey)
  return kept
}

export function trackImage(chatKey, sender, msg) {
  if (!chatKey || !sender || !msg?.message?.imageMessage) return

  const now = Date.now()
  const list = prune(chatKey, sender, now)

  const last = list[list.length - 1]
  if (last && last.key === msg.key?.id) return

  list.push({ at: now, key: msg.key?.id, msg, sender })
  recent.set(chatKey, list)
}

export function __resetRecent() {
  recent.clear()
}

async function toJpeg(buffer) {
  const out = await sharp(buffer, { animated: false })
    .flatten({ background: '#ffffff' })
    .jpeg({ quality: 92 })
    .toBuffer({ resolveWithObject: true })
  return { data: out.data, width: out.info.width, height: out.info.height }
}

export default {
  name: 'topdf',
  command: ['topdf', 'img2pdf', 'imagepdf', 'gambartopdf'],
  allow: CHAT.BOTH,
  roleRequired: 10,
  category: 'tools',
  description: 'Convert one or many images into a single PDF file',

  async handle(ctx) {
    const { sock, chat, msg } = ctx
    const now = Date.now()

    const sizeArg = String(ctx.args?.[0] || '').trim().toLowerCase()
    const size = PAGE_SIZE_NAMES.includes(sizeArg) ? sizeArg : 'a4'
    const custom = /^(\d{2,5})x(\d{2,5})$/.exec(sizeArg)
    const opts = custom
      ? { width: Number(custom[1]), height: Number(custom[2]) }
      : { size }

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
    const sources = []

    if (quoted?.imageMessage) {
      sources.push({
        msg: {
          key: {
            remoteJid: chat,
            fromMe: false,
            id: ctx.msg.message.extendedTextMessage.contextInfo.stanzaId,
            participant: ctx.msg.message.extendedTextMessage.contextInfo.participant
          },
          message: quoted
        },
        label: 'gambar yang dibalas'
      })
    } else {
      const sender = ctx.sender
      const burst = prune(chat, sender, now)
      if (!burst.length) {
        await sock.sendMessage(chat, {
          text: [
            `Kirim satu atau beberapa gambar, lalu ketik ${ctx.prefix}topdf.`,
            ``,
            `Kalau mau satu gambar saja: balas gambarnya lalu ${ctx.prefix}topdf`,
            ``,
            `Ukuran halaman: ${PAGE_SIZE_NAMES.join(', ')} — contoh ${ctx.prefix}topdf letter`,
            `Atau ukuran sendiri: ${ctx.prefix}topdf 400x600`
          ].join('\n'),
          quoted: msg
        })
        return
      }
      sources.push(...burst.map((e, i) => ({
        msg: e.msg,
        label: `gambar ${i + 1} dari ${burst.length}`
      })))
    }

    await sock.sendMessage(chat, { react: { text: '⏳', key: msg.key } })

    try {
      const pages = []
      let total = 0

      for (const source of sources) {
        const buffer = await downloadMediaMessage(
          source.msg, 'buffer', {}, { logger: { level: 'silent' } }
        )
        if (!buffer?.length) {
          throw new Error(`${source.label} gagal diunduh.`)
        }

        total += buffer.length

        if (total > MAX_BYTES) {
          throw new Error(
            `Total ${sources.length} gambar melebihi batas ${Math.round(MAX_BYTES / 1024 / 1024)}MB.`
          )
        }

        const page = await toJpeg(buffer)
        if (page.width > MAX_PAGES_DIM || page.height > MAX_PAGES_DIM) {
          throw new Error(`${source.label} resolusinya terlalu besar untuk PDF.`)
        }
        pages.push(page)
      }

      const pdf = buildPdf(pages, opts)

      await sock.sendMessage(chat, {
        document: pdf,
        mimetype: 'application/pdf',
        fileName: `${sources.length === 1 ? 'gambar' : `${sources.length}-gambar`}.pdf`,
        caption: `📄 *${pages.length} halaman* → PDF (${size.toUpperCase()})`,
        quoted: msg
      })

      await sock.sendMessage(chat, { react: { text: '✅', key: msg.key } })
      logger.info(`[topdf] ${pages.length} halaman, ${pdf.length} byte`)
    } catch (error) {
      logger.error('[topdf] gagal', error)
      await sock.sendMessage(chat, {
        text: `❌ Gagal membuat PDF: ${friendly(error)}`,
        quoted: msg
      })
      await sock.sendMessage(chat, { react: { text: '❌', key: msg.key } })
    }
  }
}

function friendly(error) {
  const raw = String(error?.message || error)
    .replace(/https?:\/\/\S+/g, '')
    .replace(/\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+/g, '')
    .replace(/\s{2,}/g, ' ')
    .trim()
  return raw.length > 200 ? `${raw.slice(0, 197)}...` : raw
}