export default {
  id: 'converter',
  name: 'Media Converter',
  enabled: true,
  version: '1.0.0',
  description: 'Convert images, audio, video, and merge images into PDF'
}