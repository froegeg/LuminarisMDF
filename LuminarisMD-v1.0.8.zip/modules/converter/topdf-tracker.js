// Penglacak gambar untuk !topdf batch.
//
// File ini ada sebagai plugin event terpisah, bukan digabung ke topdf.js,
// karena bentuk plugin di loader itu terpisah: plugin yang punya `handle`
// (default) TIDAK bisa sekaligus punya `events`, sedangkan plugin event
// tidak boleh punya `handle`. Satu file untuk satu bentuk.
//
// Yang dicatat cuma gambar. Jejak disimpan di memori proses, jadi bot restart
// = jejak hilang. Itu-trade-off yang disengaja: tidak ada yang perlu dihapus
// dari database, dan data yang hilang cuma urutan gambar terakhir yang belum
// sempat dijadiin PDF.

import { trackImage } from './topdf.js'

export const name = 'topdf_tracker'
export const category = 'tools'
export const event = 'messages.upsert'

export async function onEvent(_sock, payload) {
  if (payload?.type !== 'notify') return

  for (const msg of payload.messages ?? []) {
    // Hasil konversi bot sendiri tidak boleh ikut terhitung sebagai halaman.
    if (msg?.key?.fromMe) continue
    const chat = msg?.key?.remoteJid
    const sender = msg?.key?.participant || msg?.key?.remoteJid
    if (!chat || !sender) continue
    trackImage(chat, sender, msg)
  }
}