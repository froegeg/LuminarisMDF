export default {
  id: 'rpg',
  name: 'RPG Adventure',
  enabled: false,
  version: '1.0.0',
  description: 'RPG adventure system with mining, fishing, hunting, crafting, and economy',
  commands: [
    'rpg', 'status', 'inv', 'inventory',
    'mine', 'mining', 'fish', 'fishing',
    'hunt', 'hunting', 'adv', 'adventure',
    'shop', 'buy', 'sell', 'craft', 'make',
    'heal', 'rest', 'use'
  ],
  events: []
}