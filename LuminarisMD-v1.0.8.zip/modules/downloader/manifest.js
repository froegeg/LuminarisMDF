export default {
  id: 'downloader',
  name: 'Media Downloader',
  enabled: true,
  version: '1.0.0',
  description: 'Instagram, TikTok, YouTube, Facebook, Twitter, Pinterest & search'
}