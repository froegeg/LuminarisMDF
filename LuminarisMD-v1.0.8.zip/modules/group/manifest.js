export default {
  id: 'group',
  name: 'Group Management',
  enabled: true,
  version: '1.0.0',
  description: 'Welcome, antilink, antitoxic, mute, tags — the 80+ group features',
  events: ['messages.upsert', 'group-participants.update']
}