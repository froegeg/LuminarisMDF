import { CHAT, senderJid, toJid, peekName } from '#core'
import { jidDecode, jidNormalizedUser } from '@laminaris/baileys'

const CARD_TYPES = ['interactiveMessage', 'buttonsMessage', 'templateMessage', 'listMessage']

const WRAPPERS = [
  'ephemeralMessage',
  'viewOnceMessage',
  'viewOnceMessageV2',
  'viewOnceMessageV2Extension',
  'documentWithCaptionMessage',
  'editedMessage',
  'deviceSentMessage',
  'botInvokeMessage'
]

const LIMIT = 3
const COUNT_TTL_MS = 24 * 60 * 60 * 1000
const ENABLED_TTL_MS = 5000
const MAX_UNWRAP_DEPTH = 8

const ENABLED_KEY = 'antibotEnabled'
const COUNTS_KEY = 'antibotViolations'

const enabledCache = new Map()

function detectCard(message) {
  let m = message
  for (let depth = 0; depth < MAX_UNWRAP_DEPTH && m && typeof m === 'object'; depth++) {
    for (const type of CARD_TYPES) {
      if (m[type]) return type
    }
    const next = WRAPPERS.map((w) => m[w]?.message).find(Boolean)
    if (!next) return null
    m = next
  }
  return null
}

function pruneExpired(violations, now = Date.now()) {
  const out = {}
  for (const [jid, entry] of Object.entries(violations || {})) {
    if (entry && now - (entry.at || 0) < COUNT_TTL_MS) out[jid] = entry
  }
  return out
}

const sameUser = (a, b) => {
  const ua = typeof a === 'string' ? jidDecode(a)?.user : null
  const ub = typeof b === 'string' ? jidDecode(b)?.user : null
  return !!ua && ua === ub
}

function isAdmin(meta, jid) {
  if (!meta) return false
  if (Array.isArray(meta.admins) && meta.admins.length) {
    return meta.admins.some((admin) => sameUser(admin, jid))
  }
  const admins = (meta.participants || []).filter((p) => p.admin)
  return admins.some((p) =>
    [p.id, p.phoneNumber, p.lid].filter(Boolean).some((field) => sameUser(field, jid))
  )
}

async function isEnabled(moduleData, chat) {
  const hit = enabledCache.get(chat)
  const now = Date.now()
  if (hit && now - hit.at < ENABLED_TTL_MS) return hit.value

  const stored = moduleData ? await moduleData.group.get(chat, ENABLED_KEY) : null
  const value = stored !== false
  enabledCache.set(chat, { value, at: now })
  return value
}

function cacheEnabled(chat, value) {
  enabledCache.set(chat, { value, at: Date.now() })
}

async function handleViolation(ctx, msg, chat, cardType) {
  const { sock, moduleData } = ctx
  if (!moduleData) return

  const sender = senderJid(msg)
  if (!sender) return

  const owner = toJid(process.env.OWNER_JID)
  if (owner && sender === owner) return

  const meta = await sock.groupMetadata(chat).catch(() => null)
  if (isAdmin(meta, sender)) return

  const violations = pruneExpired(await moduleData.group.get(chat, COUNTS_KEY))
  const count = (violations[sender]?.count || 0) + 1
  const tag = `@${peekName([sender]) || jidNormalizedUser(sender).split('@')[0]}`

  if (count < LIMIT) {
    violations[sender] = { count, at: Date.now() }
    await moduleData.group.set(chat, COUNTS_KEY, violations)
    await sock.sendMessage(chat, {
      text: [
        `⚠️ Peringatan ${count}/${LIMIT} ${tag}`,
        `Pesan kartu/template bot (${cardType}) tidak diizinkan di sini.`,
        `Pelanggaran ke-${LIMIT} → kamu akan dikeluarkan dari grup.`
      ].join('\n'),
      mentions: [sender]
    })
    return
  }

  try {
    await sock.groupParticipantsUpdate(chat, [sender], 'remove')
  } catch (error) {
    violations[sender] = { count, at: Date.now() }
    await moduleData.group.set(chat, COUNTS_KEY, violations)
    await sock.sendMessage(chat, {
      text: [
        `🚫 ${tag} mencapai ${LIMIT} pelanggaran tapi gagal dikeluarkan.`,
        `Alasan: ${error.message}`,
        'Pastikan bot menjadi admin grup.'
      ].join('\n'),
      mentions: [sender]
    })
    return
  }

  delete violations[sender]
  if (Object.keys(violations).length) await moduleData.group.set(chat, COUNTS_KEY, violations)
  else await moduleData.group.delete(chat, COUNTS_KEY)
  await sock.sendMessage(chat, {
    text: `🚫 ${tag} dikeluarkan dari grup setelah ${LIMIT} pelanggaran (kartu/bot).`,
    mentions: [sender]
  })
}

async function handleUpsert(ctx) {
  const { payload, sock, moduleData } = ctx
  if (payload?.type !== 'notify' || !moduleData) return

  for (const msg of payload.messages || []) {
    if (!msg?.message || msg.key?.fromMe) continue

    const chat = msg.key.remoteJid
    if (!chat?.endsWith('@g.us')) continue

    const cardType = detectCard(msg.message)
    if (!cardType) continue

    if (!(await isEnabled(moduleData, chat))) continue

    try {
      await handleViolation(ctx, msg, chat, cardType)
    } catch (error) {
      console.warn(`[antibot] gagal proses pelanggaran di ${chat}: ${error.message}`)
    }
  }
}

async function handleCommand(ctx) {
  const { sock, chat, msg, args, moduleData, prefix } = ctx
  if (!moduleData) return

  const sub = (args[0] || '').toLowerCase()
  const cmd = `${prefix}antibot`

  if (sub === 'on' || sub === 'off') {
    const value = sub === 'on'
    await moduleData.group.set(chat, ENABLED_KEY, value)
    cacheEnabled(chat, value)
    return sock.sendMessage(chat, {
      text: `Anti-bot ${value ? 'aktif ✅' : 'nonaktif ❌'} di grup ini.`
    }, { quoted: msg })
  }

  if (sub === 'reset') {
    await moduleData.group.delete(chat, COUNTS_KEY)
    return sock.sendMessage(chat, { text: 'Hitungan pelanggaran anti-bot direset.' }, { quoted: msg })
  }

  if (sub) {
    return sock.sendMessage(chat, {
      text: `Subcommand tidak dikenal: ${sub}\n\n${cmd} — status\n${cmd} on|off\n${cmd} reset`
    }, { quoted: msg })
  }

  const enabled = await isEnabled(moduleData, chat)
  const violations = pruneExpired(await moduleData.group.get(chat, COUNTS_KEY))
  const total = Object.keys(violations).length

  await sock.sendMessage(chat, {
    text: [
      '*Anti-bot*',
      `status   : ${enabled ? 'aktif ✅' : 'nonaktif ❌'}`,
      `limit    : ${LIMIT} pelanggaran lalu kick`,
      `tercatat : ${total} user`,
      '',
      `${cmd} on|off — ubah status`,
      `${cmd} reset — hapus semua hitungan`
    ].join('\n')
  }, { quoted: msg })
}

export default {
  name: 'antibot',
  command: ['antibot', 'antibotguard'],
  event: ['messages.upsert'],
  allow: CHAT.GROUP,
  role: 5,
  category: 'group',
  description: 'Kick members sending bot cards (interactive/buttons/template/list) after 3 warnings',

  async handle(ctx) {
    if (ctx.type === 'event') {
      if (ctx.event !== 'messages.upsert') return
      return handleUpsert(ctx)
    }
    return handleCommand(ctx)
  }
}
