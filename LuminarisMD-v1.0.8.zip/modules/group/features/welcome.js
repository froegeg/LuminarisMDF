import sharp from 'sharp'
import { CHAT, logger, sendLinkPreview, lookupName } from '#core'
import { renderMemberBanner } from '../../utility/lib/banner.js'

const DEFAULT_MESSAGES = {
  welcomeMsg: 'Halo *{user}*! Selamat datang di *{subject}*.\n\nAnggota sekarang: *{count}* orang.\nKetik !help untuk melihat daftar perintah yang tersedia.',
  leaveMsg: '*{user}* ({phone}) keluar dari *{subject}*.\nAnggota sekarang: *{count}* orang.'
}

function phoneFromJid(jid) {
  if (!jid) return ''
  return jid.split('@')[0] || ''
}

function toJid(value) {
  if (!value) return ''
  const s = String(value).trim()
  if (!s) return ''
  const at = s.indexOf('@')
  if (at < 0) return `${s}@s.whatsapp.net`
  const user = s.slice(0, at).split(':')[0]
  const server = s.slice(at + 1).split('@')[0]
  return `${user}@${server}`
}

const PIC_FETCH_TIMEOUT_MS = 5_000
const PIC_MAX_BYTES = 2 * 1024 * 1024

// Foto profil anggota untuk avatar di banner; gagal = null → inisial.
async function fetchMemberPhoto(sock, jid) {
  try {
    const url = await sock.profilePictureUrl(jid, 'image')
    if (!url) return null

    const res = await fetch(url, { signal: AbortSignal.timeout(PIC_FETCH_TIMEOUT_MS) })
    if (!res.ok) return null

    const declared = Number(res.headers.get('content-length') || 0)
    if (declared > PIC_MAX_BYTES) return null

    const buf = Buffer.from(await res.arrayBuffer())
    if (buf.length === 0 || buf.length > PIC_MAX_BYTES) return null

    const type = res.headers.get('content-type') || ''
    if (type && !type.startsWith('image/')) return null

    return buf
  } catch {
    return null
  }
}

function buildMetaIndex(meta) {
  const idx = new Map()
  for (const p of meta?.participants || []) {
    const keys = [
      p.phoneNumber ? toJid(p.phoneNumber) : null,
      p.lid ? toJid(p.lid) : null,
      p.id ? toJid(p.id) : null
    ]
    for (const k of keys) if (k && !idx.has(k)) idx.set(k, p)
  }
  return idx
}

async function resolveEntry(p, metaIdx, db) {
  let jids = []
  let phone = ''

  if (typeof p === 'string') {
    jids = [toJid(p)]
    phone = phoneFromJid(p)
  } else {
    phone = p.phoneNumber ? phoneFromJid(String(p.phoneNumber)) : phoneFromJid(p.lid)
    jids = [
      p.phoneNumber ? toJid(p.phoneNumber) : null,
      p.lid ? toJid(p.lid) : null
    ].filter(Boolean)
    if (!jids.length && p.id) jids.push(toJid(p.id))
  }

  const metaEntry = jids.map((j) => metaIdx.get(j)).find(Boolean)
  const cached = await lookupName(jids, db)
  const stubName = typeof p === 'object' ? p.name || p.pushName || p.username : null
  const metaName = metaEntry?.username || null
  const name = cached || stubName || metaName || phone || jids[0] || ''

  return {
    jid: jids[0] || '',
    phone: phone || phoneFromJid(jids[0]),
    name,
    named: !!(cached || stubName || metaName)
  }
}

const NAME_POLL_MS = 2000

async function resolveEntries(participants, metaIdx, db) {
  const waitMs = Number(process.env.WELCOME_NAME_WAIT_MS || 20000)
  const deadline = Date.now() + waitMs

  let entries = []
  for (;;) {
    entries = (await Promise.all(participants.map((p) => resolveEntry(p, metaIdx, db)))).filter(
      (e) => e.jid
    )
    if (!entries.length) return entries
    if (entries.every((e) => e.named)) return entries
    const remaining = deadline - Date.now()
    if (remaining <= 0) return entries
    await new Promise((r) => setTimeout(r, Math.min(NAME_POLL_MS, remaining)))
  }
}

export default {
  name: 'welcome',
  command: ['welcome', 'goodbye', 'leave'],
  event: ['group-participants.update'],
  allow: CHAT.GROUP,
  roleRequired: 5,
  category: 'group',
  description: 'Welcome/goodbye messages on member join/leave',

  async handle(ctx) {
    const { sock, moduleData, type, db } = ctx
    
    if (type === 'event') {
      const { id, action, participants } = ctx.payload
      if (!['add', 'remove'].includes(action) || !participants?.length) return

      const key = action === 'add' ? 'welcomeMsg' : 'leaveMsg'
      const settings = (await moduleData.group.get(id, 'messageSettings')) || {}
      const raw = settings[key]

      let text
      if (raw === false) text = ''
      else if (raw) text = raw
      else text = DEFAULT_MESSAGES[key] || ''

      if (!text) return

      let meta = null
      try {
        meta = await sock.groupMetadata(id)
      } catch {}

      const metaIdx = buildMetaIndex(meta)
      const entries = await resolveEntries(participants, metaIdx, db)
      if (!entries.length) return

      logger.info(
        `[welcome] Sapaan ${action} untuk ${entries.map((e) => e.name).join(', ')} ` +
        `(${entries.map((e) => e.phone).join(', ')}) di ${meta?.subject || id}`
      )

      const template = text
        .replaceAll('{subject}', meta?.subject || '')
        .replaceAll('{user}', entries.map((e) => e.name).join(', '))
        .replaceAll('{phone}', entries.map((e) => e.phone).join(', '))
        .replaceAll('{count}', String(meta?.participants?.length ?? entries.length))

      const mentions = action === 'add' ? entries.map((e) => e.jid) : []
      const names = entries.map((e) => e.name).join(', ')
      const count = String(meta?.participants?.length ?? entries.length)
      const subject = meta?.subject || ''

      try {
        const kind = action === 'add' ? 'welcome' : 'leave'
        const bannerPng = await renderMemberBanner(
          kind,
          names,
          await fetchMemberPhoto(sock, entries[0].jid)
        )
        const thumbnail = await sharp(bannerPng)
          .resize(1024, 512, { fit: 'contain', background: '#000000' })
          .flatten()
          .jpeg({ quality: 85, mozjpeg: true })
          .toBuffer()

        await sendLinkPreview(sock, {
          chat: id,
          text: template,
          thumbnail,
          title: `${kind === 'welcome' ? 'WELCOME' : 'LEAVE'} ✦ ${subject}`,
          description:
            action === 'add'
              ? `Anggota baru ${names} — total ${count} orang.`
              : `${names} (${entries[0].phone}) keluar — sisa ${count} orang.`,
          mentionedJid: mentions
        })
        return
      } catch (err) {
        logger.warn(`[welcome] Banner gagal dikirim, fallback teks polos: ${err?.message || err}`)
      }

      const content = { text: template }
      if (mentions.length) content.mentions = mentions
      try {
        return await sock.sendMessage(id, content)
      } catch (err) {
        logger.warn(`[welcome] Fallback teks juga gagal, sapaan terlewat: ${err?.message || err}`)
      }
      return
    }

    const chat = ctx.chat
    const command = ctx.trigger
    const key = command === 'welcome' ? 'welcomeMsg' : 'leaveMsg'
    const label = command === 'welcome' ? 'Welcome' : 'Goodbye'
    const settings = (await moduleData.group.get(chat, 'messageSettings')) || {}

    if (!ctx.args.length) {
      const cmd = ctx.prefixes[0] + command
      const raw = settings[key]
      const current =
        raw === false ? 'off' : (raw || `(default: ${DEFAULT_MESSAGES[key] || 'none'})`)
      return sock.sendMessage(chat, {
        text: `${label} message: ${current}\n\n${cmd} <text> to set, ${cmd} off to disable.\nPlaceholders: {subject} {user} {phone} {count}`
      }, { quoted: ctx.msg })
    }

    const next = { ...settings }
    if (ctx.args[0].toLowerCase() === 'off') {
      next[key] = false
    } else {
      next[key] = ctx.args.join(' ')
    }

    await moduleData.group.set(chat, 'messageSettings', next)

    await sock.sendMessage(chat, { react: { text: '✅', key: ctx.msg.key } })
  }
}