export default {
  id: 'store',
  name: 'Store & Checkout',
  enabled: false, // GLOBAL TOGGLE: disabled modules consume 0 RAM, 0 CPU
  version: '1.0.0',
  description: 'Cart, products, checkout',
  commands: ['cart', 'addproduct', 'checkout'],
  events: []
}