import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { registry } from '#core'
import { getBotSettings } from '#core'
import { ui } from '#core'
import { CHAT, ownerJid } from '#core'


const BANNER = join(process.cwd(), 'assets', 'banner.jpg')

const READMORE = String.fromCharCode(8206).repeat(4001)

const INFO_SECTION = 'Semua Fitur'
const REPORT_CATEGORY = 'LAPORKAN'
const INFO_CATEGORY = 'INFO'

function visibleFor({ isOwner, isPremium, isGroup }) {
  return (plugin) => {
    if (plugin.category === 'owner' && !isOwner) return false
    if (plugin.isPremium && !isPremium && !isOwner) return false
    if (plugin.chatType === CHAT.GROUP && !isGroup) return false
    if (plugin.chatType === CHAT.PRIVATE && isGroup) return false

    return true
  }
}

export default {
  name: 'help',
  command: ['help', 'menu', 'commands', 'h', 'allmenu', 'menuall'],
  allow: CHAT.BOTH,
  category: 'general',
  description: 'List bot commands',

  async handle(ctx) {
    const { sock, chat, msg, db } = ctx
    const settings = await getBotSettings(db)
    const prefix = settings.prefixes[0] || '!'
    const visible = visibleFor(ctx)
    const plugins = [...registry.values()]
    const args = ctx.args ?? []

    const owner = ownerJid()
    const digits = owner ? owner.split('@')[0].replace(/\D/g, '') : ''
    const reportUrl = digits.length >= 8 && digits.length <= 15 ? `https://wa.me/${digits}` : null

    if (ctx.trigger === 'allmenu' && ctx.trigger === 'menuall') {
      await sendFullMenu(sock, chat, msg, plugins, visible, prefix)
      return
    }
    
    if (args.length) {
      await sendCategory(sock, chat, msg, plugins, visible, prefix, args, reportUrl)
      return
    }

    const { isGroup } = ctx
    const name = ctx.senderName || 'Kak'

    let image = null

    try {
      image = readFileSync(BANNER)
    } catch (err) {
      console.error('[help] banner tidak terbaca:', err?.message || err)
    }

    const cats = ui.menuCategories(plugins, visible)

    const leadSections = [
      {
        title: "FROEGEG",
        rows: [
          {
            header: '✦ ✧ ʟᴜᴍɪɴᴀʀɪꜱ𝗠𝗗 ✧ ✦',
            title: 'WhatsApp Bot multi-device',
            description: 'Powered by : `@kizuna/baileys`',
            id: `${prefix}owner`
          }
        ]
      },
      {
        title: "LAPORKAN BUG",
        rows: [
          {
            header: '🐛 Laporkan Bug',
            title: 'Laporkan bug ke owner',
            description: 'Hubungi owner lewat WhatsApp',
            id: `${prefix}menu ${REPORT_CATEGORY}`
          }
        ]
      },
       {
        title: 'INFORMASI',
        rows: [
          {
            header: '',
            title: `📋 ${prefix}allmenu`,
            description: 'Semua kategori, daftar penuh tanpa batas',
            id: `${prefix}allmenu`
          }
        ]
      }
    ]


    const { content, total } = ui.buildMenuCard(
      plugins,
      prefix,
      visible,
      {
        image,

        rawBody: true,
        rawFooter: true,

        leadSections,
        

        body: () =>
          [
            '╭━━━━━━[ 1.0.8 ]━━━━━━╮',
            '   ✦ ʟᴜᴍɪɴᴀʀɪꜱ (ᴋɪᴢᴜɴᴀ) ✦   ',
            '',
            '',
            `     𝑯𝒆𝒍𝒍𝒐, _*${name}*_ 👋`,
            '',
            '',
            '· ───────────────── ·',
            '',
            'Ketuk tombol Menu di bawah, lalu',
            'pilih perintah yang mau dijalankan.',
            '',
            READMORE,
            '╭╮ `✦ *𝖬𝖤𝖭𝖴 𝖢𝖠𝖳𝖤𝖦𝖮𝖱𝖸*`',
            ...cats.map(({ category, features }) => `││ ▸ ${category} : ${features} fitur`),
            '╰╯'
          ].join('\n'),

        footer: () =>
          [
            `Use: ${prefix}menu (category) · ${prefix}allmenu`,
            'Jika ada pertanyaan, kontak owner',
            '· ── ✧ ── ·',
            ''
          ].join('\n'),

        buttonText: 'Menu'
      }
    )

    try {
      await sock.sendMessage(chat, content, { quoted: msg })
    } catch (err) {
      console.error(
        '[help] gagal kirim kartu menu:',
        err?.message || err
      )

      await sock.sendMessage(chat, {
        text: [
          '𝑳𝒖𝒎𝒊𝒏𝒂𝒓𝒊𝒔𝑴𝑫',
          '· ── ✧ ── ·',
          '',
          `Prefix  ·  ${prefix}`,
          `Commands  ·  ${total}`,
          '',
          'Menu interaktif tidak dapat ditampilkan.',
          `Ketik *${prefix}help* untuk mencoba lagi.`,
          '',
          '· ── ✧ ── ·',
          '𝑭𝒓𝒐𝒆𝒈𝒆𝒈'
        ].join('\n')
      })
    }
  }
}

async function sendCategory(sock, chat, msg, plugins, visible, prefix, args, reportUrl) {

  const asked = String(args[0] ?? '').trim().toUpperCase()

  if (asked === REPORT_CATEGORY) {
    await sock.sendMessage(
      chat,
      {
        text: reportUrl
          ? [
              '*🐛 Laporkan Bug*',
              '',
              `Ketuk untuk membuka chat owner:`,
              reportUrl,
              '',
              '_Sertakan command yang dipakai + screenshot kalau bisa._'
            ].join('\n')
          : '*🐛 Laporkan Bug*\n\nNomor owner belum diatur, jadi belum bisa dibuatkan tautan. Chat owner secara manual.'
      },
      { quoted: msg }
    )
    return
  }

  if (asked === INFO_CATEGORY) {
    await sendFullMenu(sock, chat, msg, plugins, visible, prefix)
    return
  }

  const found = ui.resolveCategory(plugins, visible, args[0])

  if (!found) {
    const cats = ui.menuCategories(plugins, visible)

    await sock.sendMessage(
      chat,
      {
        text: [
          `*Kategori tidak ditemukan*`,
          '',
          `*${prefix}menu <kategori> [halaman]*`,
          '',
          'Kategori yang tersedia:',
          `• ${prefix}menu ${REPORT_CATEGORY}`,
          `• ${prefix}menu ${INFO_CATEGORY}`,
          ...cats.map(({ category }) => `• ${prefix}menu ${category}`),
          '',
          `Ketik *${prefix}help* untuk menu lengkap.`
        ].join('\n')
      },
      { quoted: msg }
    )
    return
  }

  const view = ui.buildCategoryView(plugins, visible, found.category, found.sub)
  const { text } = ui.renderCategoryView(view, prefix, args[1])

  await sock.sendMessage(chat, { text }, { quoted: msg })
}


async function sendFullMenu(sock, chat, msg, plugins, visible, prefix) {
  const { content } = ui.buildCommandList(plugins, prefix, visible, { unlimited: true })

  try {
    await sock.sendMessage(chat, content, { quoted: msg })
  } catch (err) {
    console.error('[help] allmenu gagal kirim:', err?.message || err)
    await sock.sendMessage(
      chat,
      { text: `Daftar lengkap gagal ditampilkan. Coba lagi dengan *${prefix}help*.` },
      { quoted: msg }
    )
  }
}