import { CHAT, logger, sendLinkPreview, PREVIEW_URL } from '#core'

export default {
  name: 'demotext',
  command: ['demotext'],
  allow: CHAT.BOTH,
  role: 10,
  category: 'devDemo',
  description: 'Demo: plain text, quoted, mention, big link preview',

  async handle(ctx) {
    const { sock, msg, chat, sender, senderName } = ctx

    try {
      const jidNum = sender.replace('@s.whatsapp.net', '')

      const fkon = {
        key: {
          fromMe: false,
          participant: `${jidNum}@s.whatsapp.net`,
          remoteJid: chat
        },
        message: {
          contactMessage: {
            displayName: senderName,
            vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${senderName};;;\nFN:${senderName}\nitem1.TEL;waid=${jidNum}:${jidNum}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
            verified: true
          }
        }
      }

      await sendLinkPreview(sock, {
        chat,
        text: [
          '`✦ ✧ LuminarisMD ✧ ✦`',
          'Intelligent WhatsApp assistant.',
          'Powered by @laminaris/baileys.',
          '`Ready when you are`',
          '',
          PREVIEW_URL
        ].join('\n'),
        mentionedJid: [sender],
        contextInfo: {
          isForwarded: true,
          forwardingScore: 9,
          forwardedNewsletterMessageInfo: {
            newsletterJid: '120363410247556022@newsletter',
            newsletterName: '𝗟𝗨𝗠𝗜𝗡𝗔𝗥𝗜𝗦'
          }
        },
        quoted: fkon
      })
    } catch (err) {
      // Jangan diam: kalau ada langkah yang melempar, user harus tahu alasannya.
      logger.error(`[demotext] gagal kirim demo: ${err.message}`, err)
      await sock.sendMessage(chat, { text: `demotext gagal: ${err.message}` }, { quoted: msg })
    }
  }
}
