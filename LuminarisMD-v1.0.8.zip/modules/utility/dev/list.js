
export default {
  name: 'demolist',
  command: ['demolist'],
  role: 10,
  category: 'devDemo',
  description: 'Demo: list / single-select message',

  async handle(ctx) {
    const { sock, msg, chat } = ctx

    // Content key: sections -> listMessage (SINGLE_SELECT)
    await sock.sendMessage(
      chat,
      {
        text: 'This is a list message.\nPick one item below.',
        title: 'List Title',
        footer: 'list footer',
        buttonText: 'Tap to choose',
        sections: [
          {
            title: 'Section A',
            rows: [
              { title: 'Menu', description: 'description 1', rowId: '!menu' },
              { title: 'Item 2', description: 'description 2', rowId: '.ping' },
              { title: 'Item 3', description: 'description 3', rowId: '.menu' }
            ]
          },
          {
            title: 'Section B',
            rows: [
              { title: 'Item 4', description: 'description 4', rowId: 'list_4' },
              { title: 'Item 5', description: 'description 5', rowId: 'list_5' }
            ]
          }
        ]
      },
      { quoted: msg }
    )
  }
}