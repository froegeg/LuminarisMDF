import { CHAT } from '#core'

// Dev tool: test session dengan answer handler.
//
//   !dev_ses text              → kirim "2+2", tunggu jawaban "4"
//   !dev_ses text "3+3" "6"    → kirim "3+3", tunggu jawaban "6"
//
// Session aktif selama 60 detik. Jawaban benar → session berakhir.
// Jawaban salah → bot minta coba lagi.
// Command (prefix) tetap jalan normal saat session aktif.

// ── session store ─────────────────────────────────────────────
// chatId -> { sender, question, answer, messageKey, startTime, timeout, endTime, timer }
const sessions = new Map()

function createSession(chatId, sender, question, answer, messageKey, timeout = 60000) {
  const old = sessions.get(chatId)
  if (old?.timer) clearTimeout(old.timer)
  const session = {
    chatId,
    sender,
    question,
    answer,
    messageKey,
    startTime: Date.now(),
    timeout,
    endTime: Date.now() + timeout,
    timer: null,
  }
  sessions.set(chatId, session)
  return session
}

function getSession(chatId) {
  return sessions.get(chatId) || null
}

function endSession(chatId) {
  const session = sessions.get(chatId)
  if (session?.timer) clearTimeout(session.timer)
  sessions.delete(chatId)
  return session
}

function setSessionTimer(chatId, callback) {
  const session = sessions.get(chatId)
  if (!session) return
  const remaining = session.endTime - Date.now()
  if (remaining <= 0) {
    callback()
    sessions.delete(chatId)
    return
  }
  session.timer = setTimeout(() => {
    const current = sessions.get(chatId)
    if (current && current.startTime === session.startTime) {
      callback()
      sessions.delete(chatId)
    }
  }, remaining)
}

function hasActiveSession(chatId) {
  return sessions.has(chatId)
}

// Untuk testing: clear semua session
export function _clearSessions() {
  for (const [, session] of sessions) {
    if (session.timer) clearTimeout(session.timer)
  }
  sessions.clear()
}

// ── parser argumen ────────────────────────────────────────────
function parse(text) {
  const out = []
  let cur = ''
  let quote = null
  let open = false

  for (const ch of String(text || '')) {
    if (quote) {
      if (ch === quote) { quote = null; out.push(cur); cur = ''; open = false }
      else cur += ch
      continue
    }
    if (ch === '"' || ch === "'") { quote = ch; open = true; continue }
    if (/\s/.test(ch)) {
      if (open) { out.push(cur); cur = ''; open = false }
      continue
    }
    cur += ch
    open = true
  }
  if (open) out.push(cur)
  return out
}

// ── handler ───────────────────────────────────────────────────
async function handler(ctx) {
  const { sock, msg, chat, text, sender } = ctx

  const raw = String(text || '').replace(/^\s*[.!]?\s*dev_?ses\s*/i, '')
  const [type, ...args] = parse(raw)

  // Default: text session dengan "2+2" / "4"
  const question = args[0] || '2+2'
  const answer = args[1] || '4'

  const sentMsg = await sock.sendMessage(chat, { text: question }, { quoted: msg })
  createSession(chat, sender, question, answer, sentMsg.key, 60000)
  setSessionTimer(chat, async () => {
    const s = getSession(chat)
    if (s) {
      await sock.sendMessage(chat, { text: `⏱️ *Waktu habis!*\n\nJawaban: *${s.answer}*` })
      endSession(chat)
    }
  })
}

// ── answer handler ────────────────────────────────────────────
// Dipanggil SEBELUM command routing. Return true untuk consume pesan,
// false untuk lanjutkan ke command routing normal.
async function answerHandler(ctx) {
  const { sock, msg, chat, sender, text, prefixes } = ctx
  if (!text) return false

  // Skip command (prefix) — biarkan command routing handle
  if (prefixes.some((p) => text.startsWith(p))) return false

  const session = getSession(chat)
  if (!session) return false

  // Hanya pembuat session yang bisa jawab
  if (session.sender !== sender) return false

  const userAnswer = text.trim().toLowerCase()

  if (userAnswer === session.answer.toLowerCase()) {
    await sock.sendMessage(chat, { react: { text: '✅', key: msg.key } })
    await sock.sendMessage(chat, {
      text: `🎉 *Benar!*\n\nJawaban: *${session.answer}*`
    })
    endSession(chat)
    return true
  }

  await sock.sendMessage(chat, { react: { text: '❌', key: msg.key } })
  await sock.sendMessage(chat, {
    text: `❌ *Salah!*\n\nCoba lagi!`
  })
  return true
}

export default {
  name: 'dev_ses',
  command: ['dev_ses', 'devses'],
  allow: CHAT.BOTH,
  role: 10,
  category: 'dev',
  description: 'Dev: test session dengan answer handler',
  handle: handler,
  answerHandler,
}
