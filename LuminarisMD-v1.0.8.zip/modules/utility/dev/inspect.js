import { CHAT } from '#core'
import { AIRich } from '@laminaris/baileys'
import { getContentType, jidNormalizedUser } from '@laminaris/baileys'

export default {
  name: 'inspect',
  command: ['inspect', 'raw'],
  allow: CHAT.BOTH,
  role: 10,
  category: 'dev',
  description: 'Inspect raw message structure in absolute detail (0% filtering, 0% truncation)',

  async handle(ctx) {
    const { sock, msg, chat, sender } = ctx

    const ctxInfo = msg.message?.extendedTextMessage?.contextInfo || {}

    let label
    let target

    if (ctxInfo.quotedMessage) {
      const me = sock.user?.id ? jidNormalizedUser(sock.user.id) : null
      const participant = ctxInfo.participant ? jidNormalizedUser(ctxInfo.participant) : null

      target = {
        key: {
          remoteJid: chat,
          fromMe: !!participant && participant === me,
          id: ctxInfo.stanzaId,
          participant: participant || undefined
        },
        message: ctxInfo.quotedMessage,
        messageContextInfo: ctxInfo.messageContextInfo
      }
      label = 'Quoted message (RAW)'
    } else {
      target = msg
      label = 'Command message (RAW)'
    }

    const type = getContentType(target.message)
    const text = extractText(target.message)

    const summary = [
      `• Type: ${type || '(none)'}`,
      `• Chat: ${target.key?.remoteJid}`,
      `• From: ${target.key?.participant || sender}`,
      `• FromMe: ${target.key?.fromMe ? 'true' : 'false'}`,
      `• ID: ${target.key?.id}`,
      `• Timestamp: ${formatTs(target.message?.messageTimestamp)}`,
      `• PushName: ${msg.pushName || '-'}`,
      text ? `• Text: ${text}` : '• Text: (none)' // Removed slice(0, 120) for raw detail
    ]

    let dump
    try {
      // serializeRaw now guarantees no circular reference crashes and zero truncation
      dump = JSON.stringify(serializeRaw(target), null, 2)
    } catch (err) {
      dump = `(failed to serialize: ${err.message})\n\nFallback raw keys: ${Object.keys(target).join(', ')}`
    }

    const rich = new AIRich(sock)
    rich.setTitle(`Inspect: ${label}`)
    rich.setBody(summary.join('\n'))
    rich.addCode('json', dump)

    await rich.send(chat)
  }
}

function extractText(content) {
  const m = content || {}
  return (
    m.conversation ??
    m.extendedTextMessage?.text ??
    m.imageMessage?.caption ??
    m.videoMessage?.caption ??
    m.buttonsMessage?.contentText ??
    m.listMessage?.description ??
    m.documentMessage?.caption ??
    m.stickerMessage?.url ?? // Fallback for sticker info
    ''
  ).trim()
}

function formatTs(ts) {
  if (ts == null) return '-'
  // Handle Baileys Long object or standard number
  const n = typeof ts === 'object' && ts?.toNumber ? ts.toNumber() : Number(ts)
  if (!n || isNaN(n)) return String(ts)
  return `${new Date(n * 1000).toISOString()}  (${n})`
}

/**
 * Absolute raw serialization.
 * - NO depth limits
 * - NO string/buffer truncation
 * - Handles circular references safely
 * - Preserves Baileys protobuf Long objects
 */
function serializeRaw(obj, seen = new WeakSet()) {
  // 1. Primitive types & null
  if (obj === null || obj === undefined || typeof obj === 'boolean' || typeof obj === 'number') {
    return obj
  }

  // 2. Circular reference prevention
  if (typeof obj === 'object') {
    if (seen.has(obj)) return '[Circular Reference]'
    seen.add(obj)
  }

  // 3. Special types
  if (typeof obj === 'bigint') return `${String(obj)}n`
  if (typeof obj === 'function') return `[Function: ${obj.name || 'anonymous'}]`
  if (typeof obj === 'symbol') return `[Symbol: ${obj.toString()}]`
  if (obj instanceof Date) return obj.toISOString()
  
  // 4. Baileys Protobuf Long object handling
  if (obj && typeof obj === 'object' && typeof obj.toNumber === 'function' && typeof obj.high === 'number') {
    return { _isLong: true, value: obj.toString(), low: obj.low, high: obj.high, unsigned: obj.unsigned }
  }

  // 5. Binary data (keep 100% intact via base64)
  if (Buffer.isBuffer(obj)) return `base64:${obj.toString('base64')}`
  if (ArrayBuffer.isView(obj)) return `base64:${Buffer.from(obj.buffer, obj.byteOffset, obj.byteLength).toString('base64')}`
  if (obj instanceof ArrayBuffer) return `base64:${Buffer.from(obj).toString('base64')}`
  
  // 6. Strings (no truncation)
  if (typeof obj === 'string') return obj

  // 7. Arrays
  if (Array.isArray(obj)) return obj.map(item => serializeRaw(item, seen))

  // 8. Objects (iterate all own properties)
  const out = {}
  for (const [k, v] of Object.entries(obj)) {
    out[k] = serializeRaw(v, seen)
  }
  
  return out
}