import { CHAT, logger } from '#core'
import { proto } from '@laminaris/baileys'
import { executeWMexQuery } from '@laminaris/baileys/lib/Socket/mex.js'
import { QueryIds, XWAPaths } from '@laminaris/baileys/lib/Types/index.js'
import { getBinaryNodeChild, getBinaryNodeChildren, S_WHATSAPP_NET } from '@laminaris/baileys/lib/WABinary/index.js'
import { toNewsletterServerIds, toNewsletterUserSettingInput } from '@laminaris/baileys/lib/Socket/newsletter.js'

// Dev tool: cek & kelola newsletter (saluran) via satu command.
//
//   !dev_newsletter                       → menu
//   !dev_newsletter info <jid>            → metadata channel
//   !dev_newsletter subs <jid> [n]        → daftar subscriber
//   !dev_newsletter msgs <jid> [n]        → pesan terbaru
//   !dev_newsletter follow <jid>          → follow / unfollow
//   !dev_newsletter setname <jid> <nama>  → ubah nama / deskripsi
//   !dev_newsletter delete <jid> confirm  → hapus channel (butuh `confirm`)
//
// JID boleh diisi sebagai argumen, atau dilewati kalau NEWSLETTER_JID ada di
// .env — dipakai untuk semua subcommand yang butuh target.
//
// ── Kenapa tidak pakai `makeNewsletterSocket()` dari library ──────────
//
// Di fork ini method `newsletter*` TIDAK ditempel ke socket utama; semuanya
// dibuat lewat `makeNewsletterSocket(config)`, yang memanggil `makeSocket()` →
// `new WebSocketClient(...)` + `ws.connect()`. Memakainya berarti membuka
// koneksi WhatsApp kedua dengan kredensial yang sama, dan WA bisa memutuskan
// untuk memutus koneksi yang lebih lama.
//
// Semua query di bawah Instead-nya memakai `executeWMexQuery()` dengan
// `query` + `generateMessageTag` milik socket yang sudah ada, jadi hanya satu
// koneksi. Konsekuensinya: ini memakai deep import ke internal library
// (`@laminaris/baileys/lib/...`), yang bisa rusak kalau struktur internal
// fork berubah.

// Id tombol milik modul ini. answerHandler HANYA boleh memakai id yang
// tercantum di PAGES — kalau tidak, modul ini menelan ketukan modul lain.
const PAGES = new Set([
  '!dev_newsletter',
  '!nl_info',
  '!nl_subs',
  '!nl_msgs',
  '!nl_mine',
  '!nl_following',
  '!nl_insights',
  '!nl_admins',
  '!nl_caps',
  '!nl_enforce'
])

const DEFAULT_TRIGGER = '!dev_newsletter'
const DEFAULT_ENV_JID = 'NEWSLETTER_JID'
const DEFAULT_COUNT = 20
const MAX_COUNT = 100
const UPDATE_PATH = 'xwa2_newsletter_update'

// ── Pola pengenalan sumber target ───────────────────────────────────
//
// Target newsletter bisa datang dalam 3 bentuk, dan semua subcommand
// menerima ketiganya:
//
//   1. JID      → `120363410247556022@newsletter` (atau angka polos `120363410247556022`)
//   2. Link     → `https://whatsapp.com/channel/0029VOm9d7iaJJ8qCR6sYn`
//                  (host `wa.me` / `chat.whatsapp.com` juga diterima)
//   3. Kode     → `0029VOm9d7iaJJ8qCR6sYn` (bagian terakhir link, tanpa host)
//
// Bentuk 2 dan 3 bukan JID — keduanya harus di-resolve lewat
// `newsletterMetadata('invite', code)` dulu.
const JID_IN_TEXT_RE = /(\d{6,})@newsletter\b/i
const LINK_RE = /\bhttps?:\/\/(?:[\w-]+\.)*(?:wa\.me|whatsapp\.com|chat\.whatsapp\.com)\/channel\/([\w-]+)/i
const BARE_INVITE_RE = /^00[\w-]{16,}$/

/** Ambil ref newsletter dari teks bebas: JID, link, atau kode invite. */
function extractNewsletterRef(text) {
  const raw = String(text ?? '').trim()
  if (!raw) return null

  const jid = raw.match(JID_IN_TEXT_RE)
  if (jid) return { kind: 'jid', value: jid[1] }

  const link = raw.match(LINK_RE)
  if (link) return { kind: 'invite', value: link[1] }

  const token = raw.split(/\s+/)[0]
  if (BARE_INVITE_RE.test(token)) return { kind: 'invite', value: token }
  if (/^\d{6,}$/.test(token)) return { kind: 'jid', value: token }

  return null
}

/**
 * Scan teks panjang — mis. kalimat hasil paste yang memuat link di tengah.
 *
 * Hanya dua pola high-confidence yang dipakai di sini. Kode invite polos
 * sengaja TIDAK dicari: `0029VOm9d7iaJJ8qCR6sYn` terlalu mirip string biasa,
 * jadi hanya dibaca kalau seluruh token pertama memang invite.
 */
function extractRefFromText(text) {
  const raw = String(text ?? '')
  const jid = raw.match(JID_IN_TEXT_RE)
  if (jid) return { kind: 'jid', value: jid[1] }
  const link = raw.match(LINK_RE)
  if (link) return { kind: 'invite', value: link[1] }
  return null
}

/** Link share resmi untuk sebuah channel. */
function inviteUrl(invite) {
  return invite ? `https://whatsapp.com/channel/${invite}` : null
}

/**
 * Cari JID newsletter di dalam object pesan, sedalam mungkin.
 *
 * Sumbernya fields yang dipakai WA:
 *   - `forwardedNewsletterMessageInfo.newsletterJid` di `contextInfo`
 *     (pesan newsletter yang di-forward, termasuk yang di-quote)
 *   - `key.remoteJid` kalau pesannya memang berasal dari channel
 *
 * Buffer dilewati — msgkey/media byte array bisa besar dan tidak pernah
 * berisi JID.
 */
function jidFromMessage(msg, depth = 0) {
  if (!msg || typeof msg !== 'object' || depth > 6) return null

  if (typeof msg.remoteJid === 'string' && msg.remoteJid.endsWith('@newsletter')) return msg.remoteJid

  const info = msg.forwardedNewsletterMessageInfo
  if (typeof info?.newsletterJid === 'string' && info.newsletterJid) return info.newsletterJid

  for (const value of Object.values(msg)) {
    if (!value || typeof value !== 'object' || value instanceof Uint8Array) continue
    const found = jidFromMessage(value, depth + 1)
    if (found) return found
  }
  return null
}

// ── API ──────────────────────────────────────────────────────────────

/**
 * Bungkus query XWA newsletter ke socket yang sudah ada.
 *
 * @param {import('@laminaris/baileys').WASocket} sock
 */
function makeApi(sock) {
  const wmex = (variables, queryId, dataPath) =>
    executeWMexQuery(variables, queryId, dataPath, sock.query, sock.generateMessageTag)

  const iq = (attrs, content) =>
    sock.query({
      tag: 'iq',
      attrs: { id: sock.generateMessageTag(), type: 'get', xmlns: 'newsletter', ...attrs },
      content
    })

  const update = (jid, updates) =>
    wmex({ newsletter_id: jid, updates: { settings: null, ...updates } }, QueryIds.UPDATE_METADATA, UPDATE_PATH)

  const metadataQuery = (key, type) =>
    wmex(
      {
        fetch_creation_time: true,
        fetch_full_image: false,
        fetch_viewer_metadata: true,
        fetch_pinned_messages: false,
        fetch_status_metadata: false,
        fetch_wamo_sub: false,
        input: { key, type: type.toUpperCase() }
      },
      QueryIds.METADATA,
      XWAPaths.xwa2_newsletter_metadata
    )

  return {
    metadata: async (jid) => parseMetadata(await metadataQuery(jid, 'jid')),

    /** Resolve invite link / kode invite → metadata channel (sekalian dapat JID-nya). */
    metadataByInvite: async (code) => parseMetadata(await metadataQuery(code, 'invite')),

    subscribers: async (jid, count) => {
      const res = await wmex(
        { input: { newsletter_id: jid, count } },
        QueryIds.FOLLOWERS,
        XWAPaths.xwa2_newsletter_followers
      )
      return (res?.followers?.edges ?? []).map((edge) => ({
        id: edge?.node?.id,
        name: edge?.node?.display_name || edge?.node?.username_info?.username || '?',
        role: edge?.role
      }))
    },

    /** Pesan terbaru. Decode minimal — plaintext saja, tanpa view metadata. */
    messages: async (jid, count) => {
      const result = await iq(
        { to: S_WHATSAPP_NET },
        [{ tag: 'messages', attrs: { count: String(count), type: 'jid', jid } }]
      )
      const node = getBinaryNodeChild(result, 'messages')
      if (!node) return []

      return getBinaryNodeChildren(node, 'message')
        .map((child) => {
          const plaintext = getBinaryNodeChild(child, 'plaintext')
          let text
          if (plaintext?.content) {
            try {
              // Sama seperti decodeNewsletterPlaintext di library: content dari
              // WA datang sebagai string biner, bukan utf8.
              const buf =
                typeof plaintext.content === 'string'
                  ? Buffer.from(plaintext.content, 'binary')
                  : Buffer.from(plaintext.content)
              const decoded = proto.Message.decode(buf).toJSON()
              text = decoded?.conversation || decoded?.extendedTextMessage?.text || null
            } catch {
              text = null
            }
          }
          return {
            serverId: child.attrs?.server_id ? Number(child.attrs.server_id) : null,
            time: child.attrs?.t ? Number(child.attrs.t) : null,
            fromMe: child.attrs?.is_sender === 'true',
            text: text ?? '[tidak bisa didecode]'
          }
        })
        .filter((m) => m.serverId !== null)
    },

    /** Channel yang diikuti akun ini (my_addons). */
    myAddOns: async (limit) => {
      const result = await iq({ to: S_WHATSAPP_NET }, [{ tag: 'my_addons', attrs: { limit: String(limit) } }])
      const node = getBinaryNodeChild(result, 'my_addons')
      return getBinaryNodeChildren(node, 'messages').map((group) => ({
        jid: group.attrs?.jid,
        count: getBinaryNodeChildren(group, 'message').length
      }))
    },

    following: () => wmex({}, QueryIds.SUBSCRIBED, XWAPaths.xwa2_newsletter_subscribed),

    insights: (jid) => wmex({ newsletter_id: jid }, QueryIds.INSIGHTS, XWAPaths.xwa2_newsletter_admin_insights),

    adminInfo: async (jid) => {
      const res = await wmex({ newsletter_id: jid }, QueryIds.ADMIN_INFO, XWAPaths.xwa2_newsletter_admin_info)
      return {
        adminCount: res?.admin_count ?? 0,
        adminName: res?.admin_profile?.name || null,
        adminProfilesEnabled: res?.admin_settings?.admin_profiles_enabled ?? false
      }
    },

    adminCount: async (jid) =>
      (await wmex({ newsletter_id: jid }, QueryIds.ADMIN_COUNT, XWAPaths.xwa2_newsletter_admin_count))?.admin_count,

    capabilities: async (jid) =>
      (await wmex({ newsletter_id: jid }, QueryIds.ADMIN_CAPABILITIES, XWAPaths.xwa2_newsletter_admin_capabilities))
        ?.capabilities ?? [],

    enforcements: (jid, locale = 'en_US') =>
      wmex({ newsletter_id: jid, locale }, QueryIds.ENFORCEMENTS, XWAPaths.xwa2_channel_enforcements),

    reports: (locale = 'en_US') => wmex({ locale }, QueryIds.CHANNEL_REPORTS, XWAPaths.xwa2_channels_reports),

    pendingInvites: async (jid) => {
      const res = await wmex({ newsletter_id: jid }, QueryIds.PENDING_ADMIN_INVITES, XWAPaths.pending_admin_invites)
      return (res?.pending_admin_invites ?? []).map((invite) => ({
        id: invite?.user?.id,
        phoneNumber: invite?.user?.pn
      }))
    },

    follow: (jid) => wmex({ newsletter_id: jid }, QueryIds.FOLLOW, XWAPaths.xwa2_newsletter_join_v2),
    unfollow: (jid) => wmex({ newsletter_id: jid }, QueryIds.UNFOLLOW, XWAPaths.xwa2_newsletter_leave_v2),

    mute: (jid) =>
      wmex(toNewsletterUserSettingInput(jid, 'ADMIN_NOTIFICATIONS', true), QueryIds.UPDATE_USER_SETTING, XWAPaths.xwa2_newsletter_update_user_setting),
    unmute: (jid) =>
      wmex(toNewsletterUserSettingInput(jid, 'ADMIN_NOTIFICATIONS', false), QueryIds.UPDATE_USER_SETTING, XWAPaths.xwa2_newsletter_update_user_setting),

    updateName: (jid, name) => update(jid, { name }),
    updateDescription: (jid, description) => update(jid, { description }),
    removePicture: (jid) => update(jid, { picture: '' }),

    invite: (jid, userJid) => wmex({ newsletter_id: jid, user_id: userJid }, QueryIds.CREATE_ADMIN_INVITE, XWAPaths.xwa2_newsletter_admin_invite_create),
    revokeInvite: (jid, userJid) => wmex({ newsletter_id: jid, user_id: userJid }, QueryIds.REVOKE_ADMIN_INVITE, XWAPaths.xwa2_newsletter_admin_invite_revoke),
    acceptInvite: (jid) => wmex({ newsletter_id: jid }, QueryIds.ACCEPT_ADMIN_INVITE, XWAPaths.xwa2_newsletter_admin_invite_accept),

    demote: (jid, userJid) => wmex({ newsletter_id: jid, user_id: userJid }, QueryIds.DEMOTE, XWAPaths.xwa2_newsletter_demote),
    changeOwner: (jid, userJid) => wmex({ newsletter_id: jid, user_id: userJid }, QueryIds.CHANGE_OWNER, XWAPaths.xwa2_newsletter_change_owner),

    pin: (jid, serverIds) =>
      wmex({ newsletter_id: jid, input: { message_ids: toNewsletterServerIds(serverIds) } }, QueryIds.PIN_MESSAGES, XWAPaths.xwa2_newsletter_pin_messages),
    unpin: (jid, serverIds) =>
      wmex({ newsletter_id: jid, input: { message_ids: toNewsletterServerIds(serverIds) } }, QueryIds.UNPIN_MESSAGES, XWAPaths.xwa2_newsletter_unpin_messages),

    create: (name, description) =>
      wmex({ input: { name, description: description ?? null } }, QueryIds.CREATE, XWAPaths.xwa2_newsletter_create),

    delete: (jid) => wmex({ newsletter_id: jid }, QueryIds.DELETE, XWAPaths.xwa2_newsletter_delete_v2)
  }
}

// ── Format ───────────────────────────────────────────────────────────

/**
 * Prioritas: ref dari argumen (JID / link / kode invite), lalu pesan yang
 * sedang diproses (untuk pesan newsletter yang di-forward atau di-quote),
 * terakhir `NEWSLETTER_JID` dari .env.
 *
 * `ref` sudah di-parse oleh `parseAction` (objek `{kind, value}`) atau null.
 * Async karena link invite harus di-resolve ke JID lewat jaringan.
 *
 * @returns {Promise<{jid: string|null, via: string, ref: object|null, meta?: object}>}
 */
async function resolveTarget(api, ctx, ref) {
  // 1. Argumen eksplisit.
  if (ref) {
    if (ref.kind === 'jid') {
      return { jid: `${ref.value}@newsletter`, via: 'argumen', ref }
    }
    const meta = await api.metadataByInvite(ref.value)
    if (!meta?.id) {
      throw new Error(`Invite \`${ref.value}\` tidak resolve ke channel mana pun`)
    }
    return { jid: meta.id, via: 'invite', ref, meta }
  }

  // 2. Pesan yang diproses: newsletter yang di-forward / di-quote, atau chat
  //    yang memang berada di dalam channel.
  const fromMsg = jidFromMessage(ctx.msg)
  if (fromMsg) return { jid: fromMsg, via: 'pesan', ref: null }

  // 3. .env
  const fromEnv = extractNewsletterRef(process.env[DEFAULT_ENV_JID])
  if (fromEnv?.kind === 'jid') {
    return { jid: `${fromEnv.value}@newsletter`, via: 'env', ref: fromEnv }
  }
  if (fromEnv?.kind === 'invite') {
    const meta = await api.metadataByInvite(fromEnv.value)
    if (meta?.id) return { jid: meta.id, via: 'env', ref: fromEnv, meta }
  }

  return { jid: null, via: 'tidak ditemukan', ref: null }
}

function parseCount(raw, fallback = DEFAULT_COUNT) {
  const n = Number.parseInt(raw, 10)
  if (!Number.isFinite(n) || n < 1) return fallback
  return Math.min(n, MAX_COUNT)
}

function fmtDate(seconds) {
  if (!seconds) return '-'
  return new Date(Number(seconds) * 1000).toISOString().replace('T', ' ').slice(0, 19)
}

function preview(value, max = 900) {
  const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2)
  if (!text) return '(kosong)'
  return text.length > max ? `${text.slice(0, max)}\n… (truncated)` : text
}

function code(text) {
  return `\`\`\`\n${text}\n\`\`\``
}

/** Sama seperti parseNewsletterMetadata di library: dukung {id} dan {result:{id}}. */
function parseMetadata(result) {
  if (typeof result !== 'object' || result === null) return null
  if (typeof result.id === 'string') return result
  if (typeof result.result === 'object' && result.result !== null && typeof result.result.id === 'string') return result.result
  return null
}

// ── Subcommand ───────────────────────────────────────────────────────

/**
 * @param {object} ctx
 * @param {ReturnType<makeApi>} api
 * @param {string[]} args -setelah subcommand, dengan JID_target sudah dibuang-
 */
/**
 * @param {object} ctx
 * @param {ReturnType<makeApi>} api
 * @param {object} args
 * @param {string} args.candidate -ref dari argumen pertama, sudah dikeluarkan dari rest-
 * @param {string[]} args.rest -sisa argumen-
 * @param {{jid: string|null, via: string}} args.target -hasil resolve, diisi di bawah-
 */
async function run(action, ctx, api, args) {
  const { chat, sock } = ctx

  const send = (text) => sock.sendMessage(chat, { text })

  // Resolve target SEKALI di awal: argumen → pesan → .env. Semua subcommand
  // yang butuh target memakai `needTarget()` di bawah, jadi invite lookup
  // yang mahal tidak diulang.
  args.target = await resolveTarget(api, ctx, args.candidate)

  const needTarget = () => {
    if (!args.target.jid) {
      throw new Error(
        `Target newsletter belum ditemukan. Kirim \`<jid>\`, \`https://whatsapp.com/channel/<kode>\`, ` +
          `atau reply pesan newsletter ini. Fallback: set \`${DEFAULT_ENV_JID}\` di .env`
      )
    }
    return args.target.jid
  }

  switch (action) {
    case 'jid': {
      if (!args.target.jid) return needTarget()
      // Kalau target datang dari invite link, metadata-nya sudah diambil.
      const meta = args.target.meta ?? (await api.metadata(args.target.jid))
      if (!meta) return send(`❎ JID \`${args.target.jid}\` valid, tapi metadata tidak bisa diambil.`)
      const link = inviteUrl(meta.invite)
      return send(
        [
          `🆔 *JID newsletter*`,
          `JID       : \`${meta.id || args.target.jid}\``,
          `Nama      : ${meta.name || '-'}`,
          `Subs      : ${meta.subscribers ?? '?'}`,
          `Link invite: ${link || '-'}`,
          `Sumber    : ${args.target.via}`
        ].join('\n')
      )
    }

    case 'link': {
      const meta = args.target.meta ?? (await api.metadata(needTarget()))
      const link = inviteUrl(meta?.invite)
      if (!link) return send(`❎ Tidak ada link invite untuk \`${needTarget()}\`.`)
      return send(
        [
          `🔗 *Link invite*`,
          link,
          '',
          `JID  : \`${meta.id || args.target.jid}\``,
          `Nama : ${meta.name || '-'}`
        ].join('\n')
      )
    }

    case 'join': {
      // Alias yang enak dibaca: follow tanpa perlu tahu itu harus pakai kode invite.
      await api.follow(needTarget())
      return send(`✅ Berhasil follow \`${args.target.jid}\`.`)
    }

    case 'info': {
      const meta = parseMetadata(await api.metadata(needTarget()))
      if (!meta) return send('❎ Metadata tidak ditemukan.')
      return send(
        [
          `📰 *${meta.name || '(tanpa nama)'}*`,
          `JID      : \`${meta.id}\``,
          `Dibuat   : ${fmtDate(meta.creation_time)}`,
          `Subs     : ${meta.subscribers ?? '?'}`,
          `Deskripsi: ${meta.description || '-'}`,
          `Verifikasi: ${meta.verification || '-'}`,
          `Mute     : ${meta.mute_state || '-'}`,
          '',
          '_raw:_\n' + code(preview(meta))
        ].join('\n')
      )
    }

    case 'subs': {
      const list = await api.subscribers(needTarget(), parseCount(args.rest[0]))
      if (!list.length) return send('Tidak ada subscriber yang dikembalikan.')
      const lines = list.map((s, i) => `${i + 1}. ${s.name} — \`${s.id}\`${s.role ? ` (${s.role})` : ''}`)
      return send(`👥 *Subscriber* (${list.length})\n\n${lines.join('\n')}`)
    }

    case 'msgs': {
      const list = await api.messages(needTarget(), parseCount(args.rest[0], 10))
      if (!list.length) return send('Tidak ada pesan yang dikembalikan.')
      const lines = list.map(
        (m) => `• \`${m.serverId}\` ${fmtDate(m.time)}${m.fromMe ? ' _(kamu)_' : ''}\n  ${m.text}`
      )
      return send(`📬 *Pesan terbaru* (${list.length})\n\n${lines.join('\n\n')}`)
    }

    case 'mine': {
      const list = await api.myAddOns(parseCount(args.rest[0], 50))
      if (!list.length) return send('Tidak ada channel yang diikuti akun ini.')
      return send(
        `🗂 *Channel yang diikuti* (${list.length})\n\n${list
          .map((c) => `• \`${c.jid}\` — ${c.count} pesan`)
          .join('\n')}`
      )
    }

    case 'following': {
      const res = await api.following()
      return send(`📰 *Subscribed*\n\n${code(preview(res))}`)
    }

    case 'insights': {
      const res = await api.insights(needTarget())
      return send(`📊 *Insights*\n\n${code(preview(res))}`)
    }

    case 'admins': {
      const jid = needTarget()
      const [info, count] = await Promise.all([api.adminInfo(jid), api.adminCount(jid)])
      return send(
        [
          `🛡 *Admin*`,
          `JID           : \`${jid}\``,
          `Jumlah admin  : ${info.adminCount}`,
          `Admin utama   : ${info.adminName || '-'}`,
          `Report count  : ${count ?? '?'}`,
          `Profiles aktif: ${info.adminProfilesEnabled}`
        ].join('\n')
      )
    }

    case 'caps': {
      const caps = await api.capabilities(needTarget())
      if (!caps.length) return send('Tidak ada capability yang dikembalikan.')
      return send(`🔑 *Capabilities* (${caps.length})\n\n${caps.map((c) => `• \`${c}\``).join('\n')}`)
    }

    case 'enforce': {
      const res = await api.enforcements(needTarget(), args.rest[0] || 'en_US')
      return send(`⚖️ *Enforcements*\n\n${code(preview(res))}`)
    }

    case 'reports': {
      const res = await api.reports(args.rest[0] || 'en_US')
      return send(`📄 *Channel reports*\n\n${code(preview(res))}`)
    }

    case 'invites': {
      const res = await api.pendingInvites(needTarget())
      return send(`✉️ *Pending admin invites*\n\n${code(preview(res))}`)
    }

    case 'follow':
      await api.follow(needTarget())
      return send('✅ Berhasil follow.')

    case 'unfollow':
      await api.unfollow(needTarget())
      return send('✅ Berhasil unfollow.')

    case 'mute':
      await api.mute(needTarget())
      return send('🔇 Notifikasi admin dimatikan.')

    case 'unmute':
      await api.unmute(needTarget())
      return send('🔔 Notifikasi admin dinyalakan.')

    case 'setname': {
      const name = args.rest.join(' ').trim()
      if (!name) throw new Error('Nama baru kosong. Contoh: `setname <jid> Nama Baru`')
      await api.updateName(needTarget(), name)
      return send(`✅ Nama diubah menjadi *${name}*.`)
    }

    case 'setdesc': {
      const description = args.rest.join(' ').trim()
      if (!description) throw new Error('Deskripsi baru kosong. Contoh: `setdesc <jid> teks`')
      await api.updateDescription(needTarget(), description)
      return send('✅ Deskripsi diubah.')
    }

    case 'delpic':
      await api.removePicture(needTarget())
      return send('✅ Foto channel dihapus.')

    case 'invite': {
      const userJid = args.rest[0]
      if (!userJid) throw new Error('JID admin yang mau diundang belum diisi.')
      await api.invite(needTarget(), userJid)
      return send(`✅ Undangan admin dikirim ke \`${userJid}\`.`)
    }

    case 'revoke': {
      const userJid = args.rest[0]
      if (!userJid) throw new Error('JID admin yang mau dicabut belum diisi.')
      await api.revokeInvite(needTarget(), userJid)
      return send(`✅ Undangan untuk \`${userJid}\` dicabut.`)
    }

    case 'accept':
      await api.acceptInvite(needTarget())
      return send('✅ Undangan admin diterima.')

    case 'demote': {
      const userJid = args.rest[0]
      if (!userJid) throw new Error('JID admin yang mau diturunkan belum diisi.')
      await api.demote(needTarget(), userJid)
      return send(`✅ \`${userJid}\` diturunkan jadi subscriber.`)
    }

    case 'setowner': {
      const userJid = args.rest[0]
      if (!userJid) throw new Error('JID pemilik baru belum diisi.')
      await api.changeOwner(needTarget(), userJid)
      return send(`✅ Ownership pindah ke \`${userJid}\`.`)
    }

    case 'pin': {
      const ids = args.rest.filter((a) => /^\d+$/.test(a))
      if (!ids.length) throw new Error('Butuh minimal satu server_id angka.')
      await api.pin(needTarget(), ids)
      return send(`📌 Dipin: ${ids.join(', ')}`)
    }

    case 'unpin': {
      const ids = args.rest.filter((a) => /^\d+$/.test(a))
      if (!ids.length) throw new Error('Butuh minimal satu server_id angka.')
      await api.unpin(needTarget(), ids)
      return send(`📌 Dilepas: ${ids.join(', ')}`)
    }

    case 'create': {
      const name = args.rest.join(' ').trim()
      if (!name) throw new Error('Nama channel belum diisi. Contoh: `create Nama Channel`')
      const res = await api.create(name, process.env.NEWSLETTER_DESCRIPTION || null)
      return send(
        `✅ Channel dibuat.\n\nJID: \`${res?.id || '?'}\`\nInvite: \`${res?.invite || '?'}\`\n\n_Simpan JID-nya untuk dipakai\` \`${DEFAULT_ENV_JID}\`.`
      )
    }

    case 'delete': {
      const jid = needTarget()
      if (String(args.rest[0] || '').toLowerCase() !== 'confirm') {
        return send(
          `⚠️ *Hapus channel?*\n\n\`${jid}\` akan dihapus permanen dan tidak bisa dibatalkan.\n\nUlangi dengan:\n\`${DEFAULT_TRIGGER} delete ${jid} confirm\``
        )
      }
      await api.delete(jid)
      return send(`🗑 Channel \`${jid}\` dihapus.`)
    }

    default:
      return send(`❓ Subcommand \`${action}\` tidak dikenal. Kirim \`${DEFAULT_TRIGGER}\` untuk lihat menu.`)
  }
}

const MENU = [
  '📰 *Newsletter Dev Tool*',
  '',
  'Format: `!dev_newsletter <sub> [target] [arg]`',
  '',
  '*Target* — semua subcommand menerima salah satu:',
  '• JID     — `120363410247556022@newsletter` (atau angka polos)',
  '• Link    — `https://whatsapp.com/channel/0029VOm9d7iaJJ8qCR6sYn`',
  '• Kode    — `0029VOm9d7iaJJ8qCR6sYn`',
  '• Pesan   — reply pesan newsletter, JID-nya dibaca dari situ',
  '• .env    — `NEWSLETTER_JID` sebagai fallback terakhir',
  '',
  '*Target*',
  '• `jid [target]` — ambil JID dari JID / link / kode / pesan',
  '• `link [target]` — link share untuk channel',
  '• `join [target]` — follow (alias dari `follow`)',
  '',
  '*Cek (read-only)*',
  '• `info <target>` — metadata channel',
  '• `subs <target> [n]` — subscriber',
  '• `msgs <target> [n]` — pesan terbaru',
  '• `mine [n]` — channel yang diikuti',
  '• `following` — daftar langganan',
  '• `insights <target>` — insights admin',
  '• `admins <target>` — info admin',
  '• `caps <target>` — capabilities',
  '• `enforce <target> [locale]` — enforcements',
  '• `reports [locale]` — laporan channel',
  '• `invites <target>` — undangan admin tertunda',
  '',
  '*Kelola*',
  '• `follow|unfollow <target>`',
  '• `mute|unmute <target>` — notifikasi admin',
  '• `setname <target> <nama>` / `setdesc <target> <teks>` / `delpic <target>`',
  '• `pin|unpin <target> <server_id...>`',
  '',
  '*Admin*',
  '• `invite <target> <user@...>` / `revoke <target> <user@...>` / `accept <target>`',
  '• `demote <target> <user@...>` / `setowner <target> <user@...>`',
  '• `create <nama>` — buat channel baru',
  '• `delete <target> confirm` — hapus channel'
].join('\n')

const QUICK_ACTIONS = [
  ['!nl_info', '🆔 Info'],
  ['!nl_subs', '👥 Subscribers'],
  ['!nl_msgs', '📬 Pesan'],
  ['!nl_admins', '🛡 Admin'],
  ['!nl_caps', '🔑 Caps'],
  ['!nl_mine', '🗂 Diikuti'],
  ['!nl_following', '📰 Subscribed'],
  ['!nl_insights', '📊 Insights'],
  ['!nl_enforce', '⚖️ Enforce']
]

const NEEDS_TARGET = new Set([
  'jid', 'link', 'join',
  'info', 'subs', 'msgs', 'insights', 'admins', 'caps', 'enforce', 'invites',
  'follow', 'unfollow', 'mute', 'unmute', 'setname', 'setdesc', 'delpic',
  'pin', 'unpin', 'delete', 'demote', 'setowner', 'invite', 'revoke'
])

function parseAction(text) {
  const trimmed = String(text || '').trim()
  if (!trimmed) return { action: null, candidate: null, rest: [] }

  const parts = trimmed.split(/\s+/)
  const action = (parts[0] || '').toLowerCase()
  const rest = parts.slice(1)

  // Subcommand boleh punya target: argumen pertama (kalau ada) dicoba
  // dibaca sebagai JID / link / kode invite.
  let candidate = null
  let tail = rest
  if (NEEDS_TARGET.has(action) && rest.length) {
    candidate = extractNewsletterRef(rest[0])
    // Gagal dibaca sebagai target → biarkan sebagai argumen biasa
    // (mis. `create Nama Channel`, atau `setname <jid> <nama>` tanpa jid).
    if (candidate) tail = rest.slice(1)
    // Kalau bukan, masih bisa jadi user paste kalimat yang memuat link/JID
    // di tengah — `!devnl jid Join channel kami: https://wa.me/channel/...`.
    // Tail tidak digeser karena target-nya bukan argumen pertama.
    else candidate = extractRefFromText(rest.join(' '))
  }

  return { action, candidate, rest: tail }
}

async function answerHandler(ctx) {
  const id = ctx.selection?.id?.trim().toLowerCase()
  if (!id || !PAGES.has(id)) return false

  const { sock, chat } = ctx

  if (id === '!dev_newsletter') {
    await sock.sendMessage(chat, {
      text: MENU,
      footer: 'newsletter dev',
      buttonText: 'Aksi cepat',
      sections: [
        {
          title: 'Cek & kelola',
          rows: QUICK_ACTIONS.map(([rowId, title]) => ({ title, description: rowId, rowId }))
        }
      ]
    })
    return true
  }

  const action = id.slice('!nl_'.length)
  const api = makeApi(ctx.sock)

  try {
    await run(action, ctx, api, { candidate: null, rest: [] })
  } catch (err) {
    logger.warn?.(`[dev_newsletter] ${action} gagal: ${err?.message || err}`)
    await sock.sendMessage(chat, { text: `❎ \`${action}\` gagal: ${err?.message || err}` })
  }
  return true
}

export default {
  name: 'dev_newsletter',
  command: ['dev_newsletter', 'devnl'],
  allow: CHAT.BOTH,
  role: 10,
  category: 'dev',
  description: 'Dev: cek & kelola newsletter (saluran)',
  answerHandler,

  async handle(ctx) {
    const { sock, chat, args } = ctx
    const { action, candidate, rest } = parseAction(args.join(' '))

    if (!action) {
      await sock.sendMessage(chat, {
        text: MENU,
        footer: 'newsletter dev',
        buttonText: 'Aksi cepat',
        sections: [
          {
            title: 'Cek & kelola',
            rows: QUICK_ACTIONS.map(([rowId, title]) => ({ title, description: rowId, rowId }))
          }
        ]
      })
      return
    }

    const api = makeApi(sock)
    try {
      await run(action, ctx, api, { candidate, rest })
    } catch (err) {
      logger.error?.(`[dev_newsletter] ${action} gagal`, err)
      await sock.sendMessage(chat, { text: `❎ \`${action}\` gagal: ${err?.message || err}` })
    }
  }
}