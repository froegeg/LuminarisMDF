

export default {
  name: 'draw',
  command: ['draw'],
  role: 10,
  category: 'devDemo',
  description: 'Demo: plain text, quoted, mention, link preview',

  async handle(ctx) {
    const { sock, msg, chat, sender } = ctx
    console.log(ctx)
  }
}