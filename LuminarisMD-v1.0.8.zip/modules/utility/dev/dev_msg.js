import { CHAT } from '#core'

// Dev tool: kirim satu tipe pesan WhatsApp untuk mengecek tampilan/render.
//
//   !dev_msg <tipe> [argumen]
//   !dev_msg                     → daftar tipe
//   !dev_msg quiz                → pakai template bawaan
//   !dev_msg quiz "2+2?" "3" "4" 1  → override template
//
// Kalau command ini di-reply, pesan yang di-reply dipakai jadi target utk tipe
// yang butuh target (react, delete, pin, dll).
//
// Cuma untuk debugging — bukan fitur bot.

// ── parser argumen ────────────────────────────────────────────
// Pecah per whitespace, tapi kutip (" atau ') menyatukan satu argumen.
function parse(text) {
  const out = []
  let cur = ''
  let quote = null
  let open = false

  for (const ch of String(text || '')) {
    if (quote) {
      if (ch === quote) { quote = null; out.push(cur); cur = ''; open = false }
      else cur += ch
      continue
    }
    if (ch === '"' || ch === "'") { quote = ch; open = true; continue }
    if (/\s/.test(ch)) {
      if (open) { out.push(cur); cur = ''; open = false }
      continue
    }
    cur += ch
    open = true
  }
  if (open) out.push(cur)
  return out
}

// Kunci pesan yang sedang di-reply (kalau ada).
function quotedKey(msg, chat) {
  const ci = msg.message?.extendedTextMessage?.contextInfo
  if (!ci?.stanzaId) return null
  return {
    remoteJid: chat,
    fromMe: false,
    id: ci.stanzaId,
    ...(ci.participant && { participant: ci.participant })
  }
}

function quotedText(msg) {
  const q = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
  if (!q) return null
  return (
    q.conversation ||
    q.extendedTextMessage?.text ||
    q.imageMessage?.caption ||
    q.videoMessage?.caption ||
    null
  )
}

// Ambil media dari pesan yang di-reply, kalau reply-nya memang media.
async function quotedMedia(msg, chat, sock) {
  const q = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
  const mc = q?.imageMessage || q?.videoMessage || q?.stickerMessage || q?.audioMessage
  if (!mc) return null
  const key = quotedKey(msg, chat)
  const target = { key, message: q }
  const buf = await sock.downloadMediaMessage(target, 'buffer', {}, { logger: { level: 'silent' } })
  return { buffer: buf, mimetype: mc.mimetype }
}

const isUrl = (s) => /^https?:\/\//i.test(s)

// ── daftar tipe ───────────────────────────────────────────────
const TYPES = {
  text: 'text [isi]',
  image: 'image [url]  · atau reply foto',
  video: 'video [url]  · atau reply video',
  audio: 'audio [url]  · atau reply audio',
  gif: 'gif [url]  · atau reply video',
  ptt: 'ptt [url]  · atau reply audio',
  document: 'document [url] [nama.pdf]',
  sticker: 'sticker [url]  · reply foto/video → stiker',
  location: 'location [lat] [lng] [nama] [alamat]',
  contact: 'contact [nama] [nomor] [org]',
  react: 'react [emoji]  · reply pesan untuk direaksi',
  delete: 'delete  · hapus pesan yang di-reply',
  pin: 'pin  · sematkan pesan yang di-reply (grup)',
  keep: 'keep  · simpan ke Koleksi (grup)',
  poll: 'poll ["Pertanyaan" "Opsi 1" "Opsi 2"]',
  quiz: 'quiz ["Pertanyaan" "Opsi 1" "Opsi 2" <index benar>]',
  buttons: 'buttons ["Judul" "Teks 1" "id_1" "Teks 2" "id_2"]',
  list: 'list ["Judul" "Grup" "Baris 1" "id_1" "Baris 2" "id_2"]',
  flow: 'flow ["Judul" quick_reply "Teks" "id"]',
  carousel: 'carousel ["Judul" <url1> "Judul kartu" <url2>]',
  sharephone: 'sharephone',
  vanish: 'vanish [detik]'
}

// ── template bawaan ───────────────────────────────────────────
// Dipakai kalau tipe dipanggil tanpa argumen.
const TEMPLATES = {
  text: ['Halo dari dev_msg! 👋'],
  image: ['https://picsum.photos/400/300'],
  video: ['https://www.w3schools.com/html/mov_bbb.mp4'],
  audio: ['https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'],
  gif: ['https://media.giphy.com/media/JIX9t2j0ZTN9S/giphy.mp4'],
  ptt: ['https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'],
  document: ['https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', 'sample.pdf'],
  sticker: ['https://picsum.photos/512/512'],
  location: ['-6.2', '106.8', 'Monas', 'Jakarta'],
  contact: ['Budi', '628123456789', 'Luminaris'],
  react: ['👍'],
  delete: [],
  pin: [],
  keep: [],
  poll: ['Makan apa?', 'Ya', 'Tidak'],
  quiz: ['2+2?', '3', '4', '1'],
  buttons: ['Pilih', 'Ya', 'yes', 'Tidak', 'no'],
  list: ['Pilih', 'Kota', 'Jakarta', 'jkt', 'Bandung', 'bdg'],
  flow: ['Pilih', 'quick_reply', 'Ya', 'yes', 'Tidak', 'no'],
  carousel: ['Promo', 'https://picsum.photos/300', 'Kartu 1', 'https://picsum.photos/301', 'Kartu 2'],
  sharephone: [],
  vanish: ['86400']
}

export default {
  name: 'dev_msg',
  command: ['dev_msg', 'devmsg'],
  allow: CHAT.BOTH,
  role: 10,
  category: 'dev',
  description: 'Dev: kirim satu tipe pesan untuk cek render (dev_msg <tipe> [args])',

  async handle(ctx) {
    const { sock, chat, text, msg, isGroup } = ctx

    const raw = String(text || '').replace(/^\s*[.!]?\s*dev_?msg\s*/i, '')
    const [type, ...args] = parse(raw)

    // ── tanpa argumen: daftar, tidak kirim apa pun ───────────
    if (!type) {
      const lines = ['*dev_msg — tipe pesan yang tersedia*', '']
      const w = Math.max(...Object.keys(TYPES).map((k) => k.length))
      for (const [k, v] of Object.entries(TYPES)) lines.push(`  ${k.padEnd(w)}  ${v}`)
      lines.push('')
      lines.push(`Reply sebuah pesan dulu untuk menguji tipe yang butuh target (react, delete, pin, keep).`)
      lines.push(`Tanpa argumen, tiap tipe memakai template bawaan.`)
      return sock.sendMessage(chat, { text: lines.join('\n') })
    }

    if (!TYPES[type]) {
      const names = Object.keys(TYPES)
      const near = names.find((n) => n.startsWith(type.slice(0, 3)))
      return sock.sendMessage(chat, {
        text: `Tipe *${type}* tidak ada.${near ? ` Maksudnya *${near}*?` : ''}\nDev_msg tanpa argumen untuk lihat daftar.`
      })
    }

    // Pakai template kalau tidak ada argumen
    const effectiveArgs = args.length > 0 ? args : (TEMPLATES[type] || [])

    // Tipe yang butuh pesan yang di-reply
    const key = quotedKey(msg, chat)
    const needQuote = ['react', 'delete', 'pin', 'keep', 'sticker', 'image', 'video', 'audio', 'gif', 'ptt', 'document']
    if (needQuote.includes(type) && !key && !effectiveArgs.some(isUrl)) {
      return sock.sendMessage(chat, { text: `*${type}* butuh pesan yang di-reply (atau URL).` })
    }

    const send = (content) => sock.sendMessage(chat, content, key ? { quoted: msg } : {})

    try {
      switch (type) {
        // ── teks ──
        case 'text': {
          const body = effectiveArgs.join(' ').trim()
          if (!body) return sock.sendMessage(chat, { text: 'Usage: `dev_msg text <isi>`' })
          return send({ text: body })
        }

        // ── media ──
        case 'image':
        case 'video':
        case 'audio':
        case 'gif':
        case 'ptt':
        case 'document': {
          const url = effectiveArgs.find(isUrl)
          const media = url ? { url } : await quotedMedia(msg, chat, sock)
          if (!media) return sock.sendMessage(chat, { text: `Tidak ada media. Reply media atau kirim URL.` })
          const caption = effectiveArgs.filter((a) => !isUrl(a)).join(' ').trim()

          if (type === 'gif') return send({ video: media, gifPlayback: true })
          if (type === 'ptt') return send({ audio: media, ptt: true })
          if (type === 'document') {
            const name = effectiveArgs.find((a) => !isUrl(a) && /\.[a-z0-9]{2,5}$/i.test(a))
            return send({ document: media, ...(name && { fileName: name }) })
          }
          return send({ [type]: media, ...(caption && { caption }) })
        }

        case 'sticker': {
          const url = effectiveArgs.find(isUrl)
          let buf
          let mimetype
          if (url) {
            const res = await fetch(url)
            buf = Buffer.from(await res.arrayBuffer())
            mimetype = res.headers.get('content-type') || 'image/jpeg'
          } else {
            const m = await quotedMedia(msg, chat, sock)
            if (!m) return sock.sendMessage(chat, { text: 'Reply foto/video dulu.' })
            buf = m.buffer
            mimetype = m.mimetype
          }
          const sharp = (await import('sharp')).default
          const webp = await sharp(buf)
            .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
            .webp()
            .toBuffer()
          return send({ sticker: webp })
        }

        // ── lokasi & kontak ──
        case 'location': {
          const lat = Number(effectiveArgs[0])
          const lng = Number(effectiveArgs[1])
          if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
            return sock.sendMessage(chat, { text: 'Usage: `dev_msg location -6.2 106.8 Monas`' })
          }
          return send({
            location: {
              degreesLatitude: lat,
              degreesLongitude: lng,
              ...(effectiveArgs[2] && { name: effectiveArgs[2] }),
              ...(effectiveArgs[3] && { address: effectiveArgs.slice(3).join(' ') })
            }
          })
        }

        case 'contact': {
          const [name, num, org] = effectiveArgs
          if (!name || !num) return sock.sendMessage(chat, { text: 'Usage: `dev_msg contact Budi 628123456789`' })
          return send({
            contacts: {
              contacts: [{
                displayName: name,
                ...(org && { organization: org }),
                phones: [{ phone: `+${num.replace(/\D/g, '')}`, type: 'CELL' }]
              }]
            }
          })
        }

        // ── aksi pada pesan yang di-reply ──
        case 'react': {
          const emoji = effectiveArgs[0] || '👍'
          return send({ react: { text: emoji, key } })
        }

        case 'delete':
          return send({ delete: key })

        case 'pin': {
          if (!isGroup) return sock.sendMessage(chat, { text: 'Pin hanya di grup.' })
          return send({ pin: key })
        }

        case 'keep': {
          if (!isGroup) return sock.sendMessage(chat, { text: 'Keep hanya di grup.' })
          return send({ keep: { ...key, keepType: 1 } })
        }

        // ── interaktif ──
        case 'poll': {
          const [q, ...opts] = effectiveArgs
          if (!q || !opts.length) return sock.sendMessage(chat, { text: 'Usage: `dev_msg poll "Makan?" "Ya" "Nidak"`' })
          return send({
            poll: {
              name: q,
              values: opts.slice(0, 12).map((o) => o.trim()).filter(Boolean),
              selectableCount: 1
            }
          })
        }

        case 'quiz': {
          const correct = Number(effectiveArgs[effectiveArgs.length - 1])
          const values = effectiveArgs.slice(1, -1)
          if (effectiveArgs.length < 4 || !Number.isInteger(correct) || correct < 0 || correct >= values.length) {
            return sock.sendMessage(chat, { text: 'Usage: `dev_msg quiz "2+2?" "3" "4" 1` (index benar: 0 atau 1)' })
          }
          return send({
            poll: {
              name: effectiveArgs[0],
              values: values.map((v) => v.trim()),
              correctOptionAnswers: [{ optionIndex: correct }],
              selectableCount: 1
            }
          })
        }

        case 'buttons': {
          const [title, ...rest] = effectiveArgs
          if (!title || rest.length < 2) {
            return sock.sendMessage(chat, { text: 'Usage: `dev_msg buttons Pilih "Ya" yes "Tidak" no`' })
          }
          const buttons = []
          for (let i = 0; i + 1 < rest.length; i += 2) {
            buttons.push({ buttonId: rest[i + 1], buttonText: { displayText: rest[i] }, type: 1 })
          }
          return send({ text: title, footer: 'dev_msg', buttons, headerType: 1 })
        }

        case 'list': {
          const [title, groupTitle, ...rest] = effectiveArgs
          if (!title || !groupTitle || rest.length < 2) {
            return sock.sendMessage(chat, { text: 'Usage: `dev_msg list Pilih "Kota" "Jakarta" jkt "Bandung" bdg`' })
          }
          const rows = []
          for (let i = 0; i + 1 < rest.length; i += 2) rows.push({ title: rest[i], id: rest[i + 1] })
          return send({
            text: title,
            footer: 'dev_msg',
            list: { title: groupTitle, description: groupTitle, sections: [{ title: groupTitle, rows }] }
          })
        }

        case 'flow': {
          const [title, ...rest] = effectiveArgs
          if (!title || rest.length < 3) {
            return sock.sendMessage(chat, { text: 'Usage: `dev_msg flow Pilih quick_reply "Ya" yes "Tidak" no`' })
          }
          const buttons = []
          for (let i = 0; i + 2 < rest.length; i += 3) {
            buttons.push({
              name: rest[i],
              buttonParamsJson: JSON.stringify({ display_text: rest[i + 1], id: rest[i + 2] })
            })
          }
          return send({ interactiveMessage: { title, footer: 'dev_msg', header: 'MENU', buttons } })
        }

        case 'carousel': {
          const [title, ...rest] = effectiveArgs
          const urls = rest.filter(isUrl)
          if (!title || !urls.length) {
            return sock.sendMessage(chat, { text: 'Usage: `dev_msg carousel Promo https://picsum.photos/300 "Kartu 1" https://picsum.photos/301 "Kartu 2"`' })
          }
          const titles = rest.filter((a) => !isUrl(a))
          const cards = urls.map((url, i) => ({
            text: titles[i] || `Kartu ${i + 1}`,
            footer: 'dev_msg',
            image: { url }
          }))
          return send({ text: title, cards })
        }

        // ── lain-lain ──
        case 'sharephone':
          return send({ sharePhoneNumber: true })

        case 'vanish':
          return send({ disappearingMessagesInChat: { enabled: true, seconds: Number(effectiveArgs[0]) || 86400 } })
      }
    } catch (err) {
      return sock.sendMessage(chat, { text: `❌ dev_msg ${type} gagal: ${err?.message || err}` })
    }
  }
}
