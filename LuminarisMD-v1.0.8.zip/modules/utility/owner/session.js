import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync } from 'node:fs'
import { join, basename } from 'node:path'
import { CHAT } from '#core'
import { getSessionGuard, quarantineSession } from '#core'
import { pendingOwnerAlerts, clearOwnerAlerts } from '#core'

const USAGE = [
  'Session — sesi tidak pernah dihapus otomatis oleh bot.',
  '',
  '!session status  — kondisi sesi, streak error, alert yang belum terkirim',
  '!session keep   — saya mau pertahankan sesi, reconnect cepat lagi',
  '!session reset  — pindahkan sesi ke karantina & pairing ulang',
  '!session restore — kembalikan karantina terakhir ke folder sesi'
].join('\n')

const sessionDir = () => process.env.SESSION_DIR || './session'
const quarantineDir = () => join(sessionDir(), '..', 'session-quarantine')

const fmtTime = (ts) => (ts ? new Date(ts).toISOString().replace('T', ' ').slice(0, 19) + ' UTC' : '—')

const STATUS_LABEL = {
  healthy: 'sehat',
  suspect: 'mencurigakan — owner sudah diberi tahu, sesi utuh',
  degraded: 'terputus sementara — sesi utuh, menunggu reconnect',
  fresh: 'belum pernah terhubung'
}

const credsSummary = (dir) => {
  const file = join(dir, 'creds.json')
  if (!existsSync(file)) return 'creds.json: tidak ada (pairing belum selesai)'
  try {
    const creds = JSON.parse(readFileSync(file, 'utf-8'))
    const parts = [`registered=${creds.registered === true}`, `me=${creds.me?.id ?? '—'}`]
    if (creds.registered !== true) parts.push('PAIRING BELUM SELESAI')
    return `creds.json: ${parts.join(', ')}`
  } catch {
    return 'creds.json: TIDAK bisa dibaca (korup)'
  }
}

function listQuarantine() {
  const dir = quarantineDir()
  if (!existsSync(dir)) return []
  return readdirSync(dir)
    .filter((name) => {
      try {
        return readdirSync(join(dir, name), { withFileTypes: true }).some((e) => e.isDirectory())
      } catch {
        return false
      }
    })
    .sort()
    .reverse()
}

/** Creds yang diselamatkan manual (dipakai `rescueSavedCreds` saat boot). */
function savedCreds() {
  try {
    return readdirSync(sessionDir()).filter((name) => /^\d{6,}-creds\.json$/.test(name))
  } catch {
    return []
  }
}

export default {
  name: 'session',
  command: ['session', 'sesi'],
  allow: CHAT.PRIVATE,
  role: 0,
  category: 'owner',
  description: 'Status sesi WhatsApp, karantina, dan pairing ulang (bot tidak pernah hapus sesi sendiri)',

  async handle(ctx) {
    const { sock, chat, args, msg } = ctx
    const sub = String(args[0] || 'status').toLowerCase()
    const guard = getSessionGuard()

    if (sub === 'status') {
      const s = guard.state
      const pending = pendingOwnerAlerts()
      const quarantine = listQuarantine()
      const cooldown = guard.cooldownRemaining()

      const lines = [
        '*Status sesi WhatsApp*',
        `Kondisi: ${STATUS_LABEL[s.status] || s.status}`,
        `Terakhir terhubung: ${fmtTime(s.lastConnectedAt)}`,
        `Gagal jaringan beruntun: ${s.networkStreak || 0}`,
        `Ditolak server beruntun: ${s.suspectStreak || 0}`,
        cooldown ? `Cooldown: ${Math.ceil(cooldown / 1000)}s lagi` : 'Cooldown: tidak aktif',
        s.lastError ? `Error terakhir: ${s.lastError.label} @ ${fmtTime(s.lastError.at)}` : 'Error terakhir: —',
        '',
        `Folder sesi: ${sessionDir()} — ${credsSummary(sessionDir())}`,
        `Salinan creds tersimpan: ${listQuarantine.length ? 'di karantina (lihat `!session restore`)' : savedCreds().join(', ') || 'tidak ada'}`,
        `Alert belum terkirim ke owner: ${pending.length}`,
        quarantine.length ? `Karantina: ${quarantine.join(', ')}` : 'Karantina: kosong'
      ]
      if (pending.length) {
        lines.push('', 'Alert tertunda:', ...pending.map((a) => `• ${a.title} @ ${fmtTime(a.at)}`))
      }
      lines.push('', USAGE)
      return sock.sendMessage(chat, { text: lines.join('\n') }, { quoted: msg })
    }

    if (sub === 'keep') {
      guard.acknowledge()
      clearOwnerAlerts()
      return sock.sendMessage(
        chat,
        {
          text: [
            'Siap, sesi DIPERTAHANKAN. Folder sesi tidak disentuh.',
            'Cooldown dan alert sebelumnya dibersihkan — reconnect jalan lagi normal.',
            'Kalau masalahnya memang tidak selesai, kabari lagi nanti; bot tetap tidak akan menghapus sesi.'
          ].join('\n')
        },
        { quoted: msg }
      )
    }

    if (sub === 'reset') {
      const confirmed = String(args[1] || '').toLowerCase() === 'confirm'
      if (!confirmed) {
        return sock.sendMessage(
          chat,
          {
            text: [
              '*Akan memindahkan sesi ke karantina* (file tidak dihapus, masih bisa dipulihkan).',
              '',
              `Folder asal: ${sessionDir()}`,
              `Tujuan: ${quarantineDir()}/<timestamp>`,
              'Setelah itu bot akan meminta pairing ulang — pastikan di HP: Settings → Linked devices, hapus entri bot yang lama DULU, baru lakukan pairing.',
              '',
              'Lanjut? `!session reset confirm`'
            ].join('\n')
          },
          { quoted: msg }
        )
      }

      const moved = quarantineSession(sessionDir(), { reason: `owner-${ctx.sender || 'reset'}` })
      if (!moved.ok) {
        return sock.sendMessage(chat, { text: `Gagal memindahkan sesi: ${moved.error}` }, { quoted: msg })
      }
      guard.resetTracking()
      clearOwnerAlerts()
      await sock.sendMessage(
        chat,
        {
          text: [
            'Sesi dipindahkan ke karantina (tidak dihapus).',
            `Cadangan: ${moved.movedTo}`,
            `Pulihkan kapan saja: pindahkan isi folder itu ke ${sessionDir()}`,
            '',
            'Bot akan pairing ulang sekarang.'
          ].join('\n')
        },
        { quoted: msg }
      )
      setTimeout(() => {
        try { sock.end(new Error('session reset by owner')) } catch {}
      }, 1_500)
      return
    }

    if (sub === 'restore') {
      const [latest] = listQuarantine()
      if (!latest) {
        return sock.sendMessage(chat, { text: 'Tidak ada karantina untuk dipulihkan.' }, { quoted: msg })
      }
      const from = join(quarantineDir(), latest)
      try {
        mkdirSync(sessionDir(), { recursive: true })
        for (const name of readdirSync(from)) {
          renameSync(join(from, name), join(sessionDir(), name))
        }
        guard.resetTracking()
        return sock.sendMessage(
          chat,
          { text: `Karantina ${basename(latest)} dikembalikan ke ${sessionDir()}. Bot akan mencoba login lagi.` },
          { quoted: msg }
        )
      } catch (err) {
        return sock.sendMessage(chat, { text: `Gagal memulihkan: ${err?.message || err}` }, { quoted: msg })
      }
    }

    return sock.sendMessage(chat, { text: USAGE }, { quoted: msg })
  }
}
