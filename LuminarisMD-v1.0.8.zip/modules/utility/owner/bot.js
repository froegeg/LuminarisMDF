import { CHAT } from '#core'
import { jidNormalizedUser } from '@laminaris/baileys'

const MAX_NAME = 25
const MAX_ABOUT = 139
const MAX_IMAGE_BYTES = 10 * 1024 * 1024

const IMAGE_MIMES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif'])
const DELETE_WORDS = new Set(['delete', 'del', 'hapus', 'remove', 'reset'])

function usage(prefix) {
  return [
    'Bot profile — kelola profil WhatsApp bot.',
    '',
    `${prefix}bot — lihat info profil saat ini`,
    `${prefix}bot name <nama> — ubah nama tampilan (maks ${MAX_NAME} huruf)`,
    `${prefix}bot about <teks> — ubah about/bio (maks ${MAX_ABOUT} huruf)`,
    `${prefix}bot profile — set foto dari gambar (reply/lampiran)`,
    `${prefix}bot profile <url> — set foto dari URL gambar`,
    `${prefix}bot profile delete — hapus foto profil`
  ].join('\n')
}

/** Kenali tipe gambar dari magic bytes (untuk hasil fetch yang tak punya header). */
function sniffImageMime(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg'
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png'
  if (buf.length > 12 && buf.subarray(0, 4).toString('ascii') === 'RIFF' && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'image/webp'
  if (buf.length > 6 && buf.subarray(0, 6).toString('ascii') === 'GIF8') return 'image/gif'
  return null
}

function normalizeText(value) {
  return value.replace(/\s+/g, ' ').trim()
}

async function readAbout(sock, botJid) {
  const list = await sock.fetchStatus(botJid)
  const entry = Array.isArray(list) ? list[0] : null
  const raw = entry?.status
  if (typeof raw === 'string') return raw || null
  return raw?.status || null
}

async function showInfo(ctx, botJid) {
  const { sock, msg, chat } = ctx

  const about = await readAbout(sock, botJid).catch(() => null)
  const photo = await sock.profilePictureUrl(botJid, 'image').catch(() => null)
  const name = sock.user?.name || '—'

  const lines = [
    '*Bot profile*',
    `name  : ${name}`,
    `about : ${about ?? '(belum diatur)'}`,
    `photo : ${photo ?? '(belum diatur)'}`,
    '',
    `ketik ${ctx.prefix || '!'}bot name/about/profile untuk mengubah`
  ]
  await sock.sendMessage(chat, { text: lines.join('\n') }, { quoted: msg })
}

async function setName(ctx) {
  const { sock, msg, chat, args, prefix } = ctx
  const name = normalizeText(args.slice(1).join(' '))

  if (!name) {
    return sock.sendMessage(chat, { text: `Nama kosong. Contoh: ${prefix}bot name LuminarisMD` }, { quoted: msg })
  }
  if (name.length > MAX_NAME) {
    return sock.sendMessage(chat, { text: `Nama terlalu panjang (${name.length}/${MAX_NAME}).` }, { quoted: msg })
  }

  try {
    await sock.updateProfileName(name)
  } catch (error) {
    return sock.sendMessage(chat, { text: `Gagal ubah nama: ${error.message}` }, { quoted: msg })
  }
  await sock.sendMessage(chat, { text: `Nama tampilan diubah menjadi *${name}*` }, { quoted: msg })
}

async function setAbout(ctx) {
  const { sock, msg, chat, args, prefix } = ctx
  const about = normalizeText(args.slice(1).join(' '))

  if (!about) {
    return sock.sendMessage(chat, { text: `About kosong. Contoh: ${prefix}bot about Bot serba bisa 🤖` }, { quoted: msg })
  }
  if (about.length > MAX_ABOUT) {
    return sock.sendMessage(chat, { text: `About terlalu panjang (${about.length}/${MAX_ABOUT}).` }, { quoted: msg })
  }

  try {
    await sock.updateProfileStatus(about)
  } catch (error) {
    return sock.sendMessage(chat, { text: `Gagal ubah about: ${error.message}` }, { quoted: msg })
  }
  await sock.sendMessage(chat, { text: 'About diperbarui.' }, { quoted: msg })
}

async function fetchImageFromUrl(url) {
  const res = await fetch(url, { redirect: 'follow' })
  if (!res.ok) throw new Error(`URL merespons ${res.status}`)

  const declared = Number(res.headers.get('content-length') || 0)
  if (declared > MAX_IMAGE_BYTES) throw new Error('Gambar terlalu besar (maks 10MB)')

  const buffer = Buffer.from(await res.arrayBuffer())
  if (buffer.length > MAX_IMAGE_BYTES) throw new Error('Gambar terlalu besar (maks 10MB)')

  const mime = sniffImageMime(buffer)
  if (!mime) throw new Error('URL itu bukan gambar yang didukung (jpg/png/webp/gif)')
  return { buffer, mimetype: mime }
}

async function readAttachedImage(ctx) {
  const { helpers, msg, chat } = ctx
  if (!helpers?.media?.extractMedia) throw new Error('Media helper tidak tersedia')

  const media = await helpers.media.extractMedia(msg, chat)
  const mime = media.mimetype && IMAGE_MIMES.has(media.mimetype)
    ? media.mimetype
    : sniffImageMime(media.buffer)

  if (!mime) throw new Error('Hanya gambar (jpg/png/webp/gif) yang bisa jadi foto profil.')
  if (media.buffer.length > MAX_IMAGE_BYTES) throw new Error('Gambar terlalu besar (maks 10MB)')
  return media.buffer
}

async function setProfile(ctx, botJid) {
  const { sock, msg, chat, args, prefix } = ctx

  if (args.length > 1 && DELETE_WORDS.has(args[1].toLowerCase())) {
    try {
      await sock.removeProfilePicture(botJid)
    } catch (error) {
      return sock.sendMessage(chat, { text: `Gagal hapus foto: ${error.message}` }, { quoted: msg })
    }
    return sock.sendMessage(chat, { text: 'Foto profil dihapus.' }, { quoted: msg })
  }

  let buffer
  try {
    const target = args[1]
    if (target && /^https?:\/\//i.test(target)) {
      ;({ buffer } = await fetchImageFromUrl(target))
    } else {
      buffer = await readAttachedImage(ctx)
    }
  } catch (error) {
    const hint = error.message?.includes('No media found')
      ? `Reply gambar atau kirim dengan caption: ${prefix}bot profile`
      : error.message
    return sock.sendMessage(chat, { text: `Gagal ambil gambar: ${hint}` }, { quoted: msg })
  }

  try {
    await sock.updateProfilePicture(botJid, buffer)
  } catch (error) {
    return sock.sendMessage(chat, { text: `Gagal ubah foto profil: ${error.message}` }, { quoted: msg })
  }
  await sock.sendMessage(chat, { text: 'Foto profil diperbarui.' }, { quoted: msg })
}

export default {
  name: 'bot',
  command: ['bot', 'setbot'],
  allow: CHAT.BOTH,
  role: 0,
  category: 'owner',
  description: 'Manage bot profile: photo, about, and display name',

  async handle(ctx) {
    const { sock, msg, chat, prefix } = ctx
    const botJid = jidNormalizedUser(sock.user?.id || '')

    if (!ctx.args.length) {
      return showInfo(ctx, botJid)
    }

    switch (ctx.args[0].toLowerCase()) {
      case 'name':
        return setName(ctx)
      case 'about':
      case 'bio':
        return setAbout(ctx)
      case 'profile':
      case 'pic':
      case 'foto':
        return setProfile(ctx, botJid)
      default:
        return sock.sendMessage(chat, { text: usage(prefix) }, { quoted: msg })
    }
  }
}
