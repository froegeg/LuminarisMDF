import { getTargetJid } from '#core'
import { CHAT } from '#core'

export default {
  name: 'premium',
  command: ['premium', 'prem'],
  allow: CHAT.BOTH,
  role: 0,
  category: 'owner',
  description: 'Toggle premium status for a user (on|off)',
  isPremium: false,

  async handle(ctx) {
    const { sock, msg, args, chat } = ctx
    const target = getTargetJid(msg)

    if (!target) {
      return sock.sendMessage(chat, { text: '❌ Mention or reply to someone to set their premium status.' }, { quoted: msg })
    }

    const action = args[0]?.toLowerCase()
    if (!['on', 'off'].includes(action)) {
      return sock.sendMessage(chat, { text: '❌ Usage: premium <on|off> (mention/reply target)' }, { quoted: msg })
    }

    const premiumOnly = action === 'on'

    const [user] = await ctx.db.write(() =>
      ctx.db.User.findOrCreate({ where: { jid: target } })
    )
    user.premium = premiumOnly
    await ctx.db.write(() => user.save())

    await sock.sendMessage(chat, {
      text: `✅ ${target} is now marked as **${premiumOnly ? 'PREMIUM' : 'REGULAR'}**.`
    }, { quoted: msg })
  }
}