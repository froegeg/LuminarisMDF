import { getBotSettings, setBotSettings } from '#core'
import { CHAT } from '#core'

export default {
  name: 'settings',
  command: ['settings', 'config'],
  allow: CHAT.BOTH,
  role: 0,
  category: 'owner',
  description: 'View / change bot settings',

  async handle(ctx) {
    const { sock, msg, args, chat, prefixes } = ctx
    const prefix = prefixes[0]

    if (!args.length) {
      const s = await getBotSettings(ctx.db)
      const lines = [
        '*Bot settings*',
        `prefixes: ${s.prefixes.join(' ')}`,
        `scope: ${s.scope}  (all | private | group)`,
        `rateLimit: ${s.rateLimit.mode}  (max ${s.rateLimit.max} per ${s.rateLimit.windowMs}ms, penalty ${s.rateLimit.penaltyMs}ms)`,
        '',
        'Usage:',
        `  ${prefix}settings prefixes <p> [p2 ...]`,
        `  ${prefix}settings prefixes reset`,
        `  ${prefix}settings scope <all|private|group>`,
        `  ${prefix}settings rl-mode <on|off>`,
        `  ${prefix}settings rl-max <n>`,
        `  ${prefix}settings rl-window <ms>`,
        `  ${prefix}settings rl-penalty <ms>`
      ]
      return sock.sendMessage(chat, { text: lines.join('\n') }, { quoted: msg })
    }

    const [key, ...values] = args.join(' ').split(/\s+/)
    const patch = buildPatch(key.toLowerCase(), values)
    if (!patch) {
      return sock.sendMessage(chat, { text: `Invalid setting: !settings ${key} ${values.join(' ')}` }, { quoted: msg })
    }

    const next = await setBotSettings(ctx.db, patch)
    await sock.sendMessage(chat, {
      text: `Updated. prefixes=${next.prefixes.join(' ')} scope=${next.scope} rl=${next.rateLimit.mode}`
    }, { quoted: msg })
  }
}

function buildPatch(key, values) {
  switch (key) {
    case 'prefix':
    case 'prefixes':
      if (!values.length) return { prefixes: null }
      if (values[0].toLowerCase() === 'reset') return { prefixes: null }
      const prefixes = [...new Set(values.map((v) => v.trim()).filter(Boolean))]
      if (!prefixes.length || prefixes.some((v) => /\s/.test(v))) return null
      return { prefixes }
    case 'scope':
      return ['all', 'private', 'group'].includes(values[0]) ? { scope: values[0] } : null
    case 'rl-mode':
      return ['on', 'off'].includes(values[0]) ? { rateLimit: { mode: values[0] } } : null
    case 'rl-max':
      return Number.isInteger(Number(values[0])) && Number(values[0]) >= 1 ? { rateLimit: { max: Number(values[0]) } } : null
    case 'rl-window':
      return Number.isInteger(Number(values[0])) && Number(values[0]) >= 1000 ? { rateLimit: { windowMs: Number(values[0]) } } : null
    case 'rl-penalty':
      return Number.isInteger(Number(values[0])) && Number(values[0]) >= 1000 ? { rateLimit: { penaltyMs: Number(values[0]) } } : null
    default:
      return null
  }
}