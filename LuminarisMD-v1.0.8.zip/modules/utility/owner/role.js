import { getTargetJid } from '#core'
import { CHAT } from '#core'

export default {
  name: 'role',
  command: ['role', 'setrole'],
  allow: CHAT.BOTH,
  role: 0,
  category: 'owner',
  description: 'Set user role 0-10. 0=root, 1-4=admin, 5=mod, 10=user',

  async handle(ctx) {
    const { sock, msg, args, chat } = ctx
    const target = getTargetJid(msg)
    if (!target) {
      return sock.sendMessage(chat, { text: 'Mention or reply to someone.' }, { quoted: msg })
    }

    const value = Number(args[0])
    if (!Number.isInteger(value) || value < 0 || value > 10) {
      return sock.sendMessage(chat, {
        text: 'Role must be 0-10. 0=root, 1-4=admin, 5=mod, 10=user.'
      })
    }

    const [user] = await ctx.db.write(() =>
      ctx.db.User.findOrCreate({ where: { jid: target } })
    )
    user.role = value
    await ctx.db.write(() => user.save())

    await sock.sendMessage(chat, { text: `Role of ${target} set to ${value}` })
  }
}