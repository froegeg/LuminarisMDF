import { CHAT } from '#core'
import { a2uiColumn, a2uiImage, a2uiText, sendA2UI } from '@laminaris/baileys'

export default {
  name: 'demoa2ui',
  command: ['demoa2ui'],
  allow: CHAT.BOTH,
  role: 10,
  category: 'devDemo',
  description: 'Demo: A2UI declarative card (experimental)',

  async handle(ctx) {
    const { sock, chat } = ctx

    // A2UI card: kartu deklaratif yang dirender klien dari spec yang dibawa
    // di dalam message (interactiveMessage.bloksWidget, type "im_a2ui").
    // Bukan HTML mini app — komponen ikut di data, tidak ada hosting.
    //
    // Layout = daftar flat yang dipesan lewat id: tepat SATU komponen root,
    // container menyebut anak-anaknya lewat id ketimbang nesting.
    //
    // CATATAN eksperimental dari library: payload bloksWidget tulis-tangan
    // terbukti render; helper sendA2UI BELUM dikonfirmasi di semua device.
    await sendA2UI(
      sock,
      chat,
      [
        a2uiColumn('root', ['card_title', 'card_body']),
        a2uiImage('card_image', 'https://raw.githubusercontent.com/alvlp-code/alvlp-code/refs/heads/main/Kuchiba.Chisa.full.4600875.png'),
        a2uiText('card_title', 'Welcome!', { variant: 'h1' }),
        a2uiText('card_body', 'Nice to have you here.\nThis is an A2UI card.')
      ],
      {
        buttons: [
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({ display_text: 'Open GitHub', url: 'https://github.com' })
          }
        ]
      }
    )
  }
}