import { CHAT } from '#core'


const CARD_IMAGE = 'assets/banner.jpg'
const PING_ACTIONS = new Set(['!ping', '!uptime'])

function formatUptime(ms) {
  const s = Math.floor(ms / 1000)
  const d = Math.floor(s / 86400)
  const h = Math.floor((s % 86400) / 3600)
  const m = Math.floor((s % 3600) / 60)
  if (d > 0) return `${d} hari ${h} jam ${m} menit`
  if (h > 0) return `${h} jam ${m} menit`
  return `${m} menit ${s % 60} detik`
}

function buildCardBody(latencyMs) {
  return [
    '> *Pong!* 🏓',
    '',
    `Latency : *${latencyMs}ms*`,
    `Uptime  : ${formatUptime(process.uptime() * 1000)}`,
    `Node    : ${process.version}`
  ].join('\n')
}

async function sendCard(sock, ui, { chat, msg, sender }) {
  const latencyMs = Date.now() - msg.messageTimestamp * 1000

  const media = await ui.prepareCardImage(sock, CARD_IMAGE).catch(() => null)

  await ui.sendViewOnceCard(sock, {
    chat,
    sender,
    media,
    text: buildCardBody(latencyMs),
    buttons: [ui.quickReply('!ping', '🕒 Ping lagi'), ui.quickReply('!uptime', '⏱️ Lihat uptime')],
    footer: 'Mungkin kamu juga mau:',
    quotedText: '🏓 Ping',
    mention: !chat.endsWith('@g.us'),
    copyCode: process.env.BOT_NAME || 'LuminarisMD',
    offerText: 'Quick Action',
    buttonLimit: 2,
    listTitle: 'Quick Action',
    buttonTitle: '🎯 Pilih',
    fallbackText: buildCardBody(latencyMs)
  })

  return latencyMs
}

async function answerHandler(ctx) {
  const id = ctx.selection?.id?.trim().toLowerCase()
  if (!id || !PING_ACTIONS.has(id)) return false

  await sendCard(ctx.sock, ctx.helpers.ui, { chat: ctx.chat, msg: ctx.msg, sender: ctx.sender })
  return true
}

export default {
  name: 'ping',
  command: ['ping', 'p'],
  allow: CHAT.BOTH,
  role: 10,
  category: 'general',
  description: 'Check bot latency',
  answerHandler,

  async handle(ctx) {
    const { sock, msg, chat, sender, helpers } = ctx

    await sock.sendMessage(chat, { react: { text: '🕒', key: msg.key } })
    await sendCard(sock, helpers.ui, { chat, msg, sender })
    await sock.sendMessage(chat, { react: { text: '✅', key: msg.key } })
  }
}