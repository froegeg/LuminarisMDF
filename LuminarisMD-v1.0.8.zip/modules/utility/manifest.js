export default {
  id: 'utility',
  name: 'Utility & Owner Tools',
  enabled: true,
  version: '1.0.0',
  description: 'Ping, help, menu, owner settings, sticker, tools, search & AI'
}