import { CHAT } from '#core'
import { RARITY_EMOJI, pickaxes, pickEnchants, biomes, travelRequirements, mobData, UPGRADES, DAILY_REWARDS, TOKEN_SHOP, GACHA_COST_COINS, GACHA_PITY_LIMIT, CRAFT_RECIPES } from './lib/data.js'
import {
  formatMoney,
  createMCUser,
  getRandomOre,
  addPickExp,
  addPlayerExp,
  getUpgradedStats,
  getStreakBonus,
  doGachaPull,
  doCombat,
  doSmelt,
  doCraft,
  doJackpotPull,
  getAvailableMobs,
  healPlayer,
  JACKPOT_POOLS,
} from './lib/engine.js'

const MC = 15
const rc = (r) => RARITY_EMOJI[r] || '⬜'
const encCost = (r) =>
  ({ common: 60000, rare: 600000, epic: 6e6, legendary: 6e7, mythic: 6e8, godly: 6e9, secret: 6e10 })[r] || 60000

async function loadMC(moduleData, sender, pushName) {
  const raw = (await moduleData.user.get(sender, 'mc')) || null
  if (raw) {
    if (!raw.pickaxes) raw.pickaxes = { woodpick: { ...pickaxes.woodpick } }
    if (!raw.pickaxes.woodpick) raw.pickaxes.woodpick = { ...pickaxes.woodpick }
    if (!raw.travelFound) raw.travelFound = ['plains']
    if (!raw.achievements) raw.achievements = []
    // Leaderboard menampilkan orang LAIN yang tidak jadi pengirim perintah,
    // jadi pushName harus ikut disimpan di record - tidak ada cara mengambilnya
    // saat render. Diperbarui tiap pemakaian supaya rename di HP ikut terbaca.
    if (pushName) raw.name = pushName
    return raw
  }
  const fresh = createMCUser()
  if (pushName) fresh.name = pushName
  return fresh
}

async function saveMC(moduleData, sender, mc) {
  try {
    await moduleData.user.set(sender, 'mc', mc)
    return true
  } catch {
    return false
  }
}

function jackpotLabel(type) {
  return { coins: 'Koin', energi: 'Energi', limit: 'Limit', tickets: 'Gacha Tickets', tokens: 'Prestige Tokens', exp_boost: 'EXP Boost', premium_7d: 'Premium 7 Hari', premium_30d: 'Premium 30 Hari', partner_7d: 'Partner 7 Hari', partner_30d: 'Partner 30 Hari', unlimited_energi: 'UNLIMITED Energi', unlimited_limit: 'UNLIMITED Limit', owner_reward: 'OWNER REWARD' }[type] || type
}

async function applyJackpotReward(mc, result) {
  const { reward, value } = result
  const type = reward.type
  const desc = (label, amt) => ({ desc: `${label} +${amt}`, type })
  switch (type) {
    case 'coins': mc.money = (mc.money || 0) + value; return desc('💰', formatMoney(value))
    case 'energi': mc.money = (mc.money || 0) + value * 10000; return desc('⚡ (→💰)', formatMoney(value * 10000))
    case 'limit': mc.money = (mc.money || 0) + value * 15000; return desc('📌 (→💰)', formatMoney(value * 15000))
    case 'tickets': mc.gachaTickets = (mc.gachaTickets || 0) + value; return desc('🎟️', value)
    case 'tokens': mc.prestigeTokens = (mc.prestigeTokens || 0) + value; return desc('🪙', value)
    case 'exp_boost': { const boost = Math.floor(mc.expToNextLevel * value * 0.5); mc.exp = (mc.exp || 0) + boost; return desc('⭐ EXP', formatMoney(boost)) }
    case 'premium_7d': case 'premium_30d': { const v = 5000000000; mc.money = (mc.money || 0) + v; return desc('👑 Premium (→💰)', formatMoney(v)) }
    case 'partner_7d': case 'partner_30d': { const v = 5000000000; mc.money = (mc.money || 0) + v; return desc('🤝 Partner (→💰)', formatMoney(v)) }
    case 'unlimited_energi': case 'unlimited_limit': { const v = 200000000000; mc.money = (mc.money || 0) + v; return desc('♾️ UNLIMITED (→💰)', formatMoney(v)) }
    case 'owner_reward': { const v = 1000000000000; mc.money = (mc.money || 0) + v; return desc('🔥 OWNER REWARD (→💰)', formatMoney(v)) }
    default: return desc('🎁 Mystery', value)
  }
}

async function reply(ctx, text) {
  return ctx.sock.sendMessage(ctx.chat, { text }, { quoted: ctx.msg })
}

async function handler(ctx) {
  const { sock, chat, sender, senderName, args, isGroup, isOwner, moduleData } = ctx
  const sa = args || []
  const sub = (sa[0] || '').toLowerCase()
  const subArgs = sa.slice(1)

  if (sub === 'on' || sub === 'off') {
    if (!isGroup) return reply(ctx, '_Toggle hanya di grup_')
    if (!isOwner) return reply(ctx, '_Hanya owner yang bisa mengatur toggle_')
    await moduleData.group.set(chat, 'mcEnabled', sub === 'on')
    return reply(ctx, sub === 'on'
      ? '*🧱 MINECRAFT ENABLED*\n\n🎮 Semua member wajib main Minecraft!\n🪧 Ketik `.mct help` untuk mulai'
      : '*🧱 MINECRAFT DISABLED*')
  }

  if (isGroup && sub !== 'on' && sub !== 'off' && (await moduleData.group.get(chat, 'mcEnabled')) === false && !isOwner) {
    return reply(ctx, '_🧱 Minecraft sedang dimatikan oleh owner._')
  }

  if (!sub || sub === 'help' || sub === 'menu') {
    return reply(ctx, [
      '*🧱 MINECRAFT GAME*',
      '_⛏️ Sistem pertambangan & 🛠️ crafting terlengkap_',
      '',
      '*⛏️ MINING*',
      '`.mct mine` _⛏️ Mulai menambang_',
      '`.mct collect` _📦 Ambil hasil_',
      '`.mct sell` _💸 Jual ore_',
      '`.mct orebook` _📚 Koleksi ore_',
      '`.mct top` _🏆 Leaderboard_',
      '',
      '*⚔️ COMBAT*',
      '`.mct fight` _👹 Daftar mob_',
      '`.mct fight <mob>` _⚔️ Lawan mob_',
      '`.mct heal` _❤️ Sembuhkan HP_',
      '`.mct stats` _📊 Stats detail_',
      '',
      '*👤 PROFILE*',
      '`.mct me` _🪪 Profil kamu_',
      '`.mct daily` _🎁 Daily reward_',
      '',
      '*🗺️ BIOME & PICKAXE*',
      '`.mct travel` _🗺️ Daftar biome_',
      '`.mct travel <biome>` _🚪 Pindah biome_',
      '`.mct shop` _🛒 Toko pickaxe_',
      '`.mct buy <pick>` _💰 Beli pickaxe_',
      '`.mct equip <pick>` _🪓 Pasang pickaxe_',
      '`.mct picks` _🎒 Koleksi pickaxe_',
      '`.mct enchant <key>` _✨ Enchant pickaxe_',
      '`.mct enchants` _📜 Daftar enchant_',
      '`.mct pickup` _⬆️ Upgrade pickaxe_',
      '',
      '*🔥 CRAFTING & SMELTING*',
      '`.mct smelt` _🔥 Smelt semua ore_',
      '`.mct craft` _🛠️ Daftar resep_',
      '`.mct craft <id>` _🧪 Craft item_',
      '`.mct inv` _🎒 Inventory_',
      '',
      '*👑 PRESTIGE*',
      '`.mct prestige` _👑 Info prestige_',
      '`.mct tokens` _🪙 Token store_',
      '`.mct upgrade` _📈 Upgrade stats_',
      '`.mct gacha` _🎰 Gacha_',
      '`.mct gacha ticket` _🎟️ Gacha pakai tiket_',
      '',
      '*🎰 JACKPOT*',
      '`.mct jackpot` _🎰 Daftar jackpot_',
      '`.mct jackpot <tier>` _💎 Main jackpot_',
    ].join('\n'))
  }

  if (sub === 'mine') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (mc.miningPending && mc.miningPending.length > 0)
      return reply(ctx, '_📦 Masih ada hasil tambang!_ `.mct collect` _dulu._')
    const now = Date.now()
    if (mc.lastMineTime && now - mc.lastMineTime < MC * 1000)
      return reply(ctx, `_⏳ Tunggu *${Math.ceil((MC * 1000 - (now - mc.lastMineTime)) / 1000)}* detik_`)
    const pk = mc.usedPickaxe || 'woodpick'
    const pick = mc.pickaxes[pk]
    if (!pick) return reply(ctx, '_🪓 Pickaxe aktif tidak ada!_ `.mct picks`')
    const bk = mc.currentBiome || 'plains'
    const st = getUpgradedStats(mc, pick)
    const ePick = { ...pick, luck: st.luck, speed: st.speed, fortuneBonus: st.fortune, sellMultiplier: st.sellMultiplier }
    const ores = []
    let tv = 0
    for (let i = 0; i < (pick.comboOre || 1); i++) {
      const ore = getRandomOre(ePick, bk)
      if (ore) {
        ore.price = Math.round(ore.price * getStreakBonus(mc.streak || 0).mult)
        ores.push(ore)
        tv += ore.price
      }
    }
    mc.miningPending = ores
    mc.lastMineTime = now
    mc.streak = (mc.streak || 0) + 1
    await saveMC(moduleData, sender, mc)

    await reply(ctx, `*_⛏️ Menambang di ${biomes[bk]?.name || bk}..._*\n_🪓 Pick: ${pick.name} | 🍀 Luck: ${(st.luck * 100).toFixed(1)}%_`)
    await new Promise((r) => setTimeout(r, Math.min(Math.max(2000, 5000 - (pick.speed || 0) * 3000), 4000)))

    let txt = '*⛏️ HASIL MENAMBANG!*\n\n'
    for (const o of ores) {
      txt += `${rc(o.rarity)} *${o.name}*\n   _💰 ${formatMoney(o.price)} | 📦 x${o.stack}_\n`
    }
    txt += `\n*💰 Total: ${formatMoney(tv)}*`
    if (mc.streak >= 3) txt += `\n_🔥 Streak: ${mc.streak}x_`
    txt += '\n\n`.mct collect` untuk 📦 mengambil!'
    return reply(ctx, txt)
  }

  if (sub === 'collect') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (!mc.miningPending || mc.miningPending.length === 0)
      return reply(ctx, '_📭 Tidak ada hasil._ `.mct mine` _dulu!_')
    const ores = mc.miningPending
    let tv = 0
    let te = 0
    const nf = []
    for (const ore of ores) {
      tv += ore.price
      te += Math.max(10, Math.floor(ore.price / 50))
      const cn = ore.name.replace(/[\u{1F300}-\u{1F9FF}]/gu, '').trim()
      if (!mc.oreFound.includes(cn)) {
        mc.oreFound.push(cn)
        nf.push(cn)
      }
    }
    mc.money = (mc.money || 0) + tv
    mc.blocksMined = (mc.blocksMined || 0) + ores.reduce((a, o) => a + (o.stack || 1), 0)
    mc.totalEarned = (mc.totalEarned || 0) + tv
    mc.inventory = [...(mc.inventory || []), ...ores]
    const rlu = addPickExp(mc, mc.usedPickaxe || 'woodpick', te)
    const plu = addPlayerExp(mc, te)
    mc.miningPending = []
    await saveMC(moduleData, sender, mc)

    let txt = `*📦 HASIL DIAMBIL!*\n\n💰 +${formatMoney(tv)}\n⭐ +${te} EXP\n🧱 +${ores.length} ore\n`
    if (nf.length > 0) txt += `\n*🆕 Ore Baru:* ${nf.join(', ')}`
    if (rlu) txt += `\n\n${rlu}`
    if (plu) txt += `\n*⬆️ LEVEL UP! Level ${mc.level}*`
    return reply(ctx, txt)
  }

  if (sub === 'sell') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (!mc.inventory || mc.inventory.length === 0)
      return reply(ctx, '_🎒 Inventory kosong!_ `.mct mine` _dulu._')
    let tv = 0
    for (const item of mc.inventory) tv += item.price || 0
    const sb = UPGRADES.fortune.effect(mc.fortuneUpgrade || 0)
    const pick = mc.pickaxes[mc.usedPickaxe || 'woodpick']
    const rsm = pick ? pick.sellMultiplier || 0 : 0
    const fv = Math.round(tv * (1 + sb + rsm))
    const fc2 = mc.inventory.length
    mc.money = (mc.money || 0) + fv
    mc.totalEarned = (mc.totalEarned || 0) + fv
    mc.inventory = []
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*💸 ORE TERJUAL!*\n\n📦 Jumlah: ${fc2}\n💰 Total: ${formatMoney(fv)}\n🏦 Saldo: ${formatMoney(mc.money)}`)
  }

  if (sub === 'me') {
    const mc = await loadMC(moduleData, sender, senderName)
    const pick = mc.pickaxes[mc.usedPickaxe || 'woodpick']
    return reply(ctx, [
      '*👤 PROFIL PENAMBANG*',
      '',
      `*⬆️ Level:* ${mc.level} _(${mc.exp}/${mc.expToNextLevel} EXP)_`,
      `*💰 Uang:* ${formatMoney(mc.money)}`,
      `*❤️ HP:* ${mc.hp}/${mc.maxHp}`,
      `*⚔️ ATK:* ${mc.atk}`,
      `*🧱 Blocks:* ${mc.blocksMined}`,
      `*🪓 Pick:* ${pick ? pick.name : '🪵 Wooden Pickaxe'} _(Lv.${pick ? pick.level : 1})_`,
      `*🗺️ Biome:* ${biomes[mc.currentBiome] ? biomes[mc.currentBiome].name : mc.currentBiome}`,
      `*🔥 Streak:* ${mc.streak || 0}`,
      `*⚔️ Combat:* ${mc.combatWins || 0}W/${mc.combatLosses || 0}L`,
      `*👑 Prestige:* ${mc.prestige || 0}`,
      `*🪙 Tokens:* ${mc.prestigeTokens || 0}`,
      `*🎟️ Tickets:* ${mc.gachaTickets || 0}`,
      `*📚 OreBook:* ${mc.oreFound ? mc.oreFound.length : 0}`,
      `*📈 Upgrades:*`,
      `  _🍀 Luck: Lv.${mc.luckUpgrade || 0}_`,
      `  _⚡ Speed: Lv.${mc.speedUpgrade || 0}_`,
      `  _💎 Fortune: Lv.${mc.fortuneUpgrade || 0}_`,
      `  _⚔️ Combat: Lv.${mc.combatUpgrade || 0}_`,
    ].join('\n'))
  }

  if (sub === 'stats') {
    const mc = await loadMC(moduleData, sender, senderName)
    const pick = mc.pickaxes[mc.usedPickaxe || 'woodpick']
    const st = getUpgradedStats(mc, pick)
    let txt = `*📊 STATS DETAIL*\n\n*🪓 Pick: ${pick ? pick.name : 'Tidak Ada'}*\n  _⬆️ Lv.${pick ? pick.level : 1}/${pick ? pick.maxLevel : 5} | ⭐ EXP ${pick ? pick.exp : 0}/${pick ? pick.expToNextLevel : 100}_\n  _🍀 Luck: ${(st.luck * 100).toFixed(1)}% | ⚡ Speed: ${(st.speed * 100).toFixed(1)}%_\n  _💎 Fortune: +${(st.fortune * 100).toFixed(1)}% | 💰 Sell: +${(st.sellMultiplier * 100).toFixed(1)}%_\n`
    if (pick && pick.enchant) {
      const e = pickEnchants[pick.enchant]
      txt += `  _✨ Enchant: ${e ? e.name : pick.enchant} (${e ? e.rarity : '?'})_\n`
    }
    txt += `\n*⚔️ Combat*\n  _⚔️ ATK: ${mc.atk} | ❤️ HP: ${mc.hp}/${mc.maxHp}_\n  _🔥 Combat Bonus: +${(UPGRADES.combat.effect(mc.combatUpgrade || 0) * 100).toFixed(1)}%_\n  _🏆 Wins: ${mc.combatWins || 0} | 💀 Losses: ${mc.combatLosses || 0}_\n`
    txt += `\n*📈 Upgrades*\n  _🍀 Luck: Lv.${mc.luckUpgrade || 0} (+${(UPGRADES.luck.effect(mc.luckUpgrade || 0) * 100).toFixed(1)}%)_\n  _⚡ Speed: Lv.${mc.speedUpgrade || 0} (+${(UPGRADES.speed.effect(mc.speedUpgrade || 0) * 100).toFixed(1)}%)_\n  _💎 Fortune: Lv.${mc.fortuneUpgrade || 0} (+${(UPGRADES.fortune.effect(mc.fortuneUpgrade || 0) * 100).toFixed(1)}%)_\n  _⚔️ Combat: Lv.${mc.combatUpgrade || 0} (+${(UPGRADES.combat.effect(mc.combatUpgrade || 0) * 100).toFixed(1)}%)_`
    return reply(ctx, txt)
  }

  if (sub === 'orebook') {
    const mc = await loadMC(moduleData, sender, senderName)
    const found = mc.oreFound || []
    if (found.length === 0) return reply(ctx, '_📚 Ore Book kosong!_ `.mct mine` _dulu_')
    let txt = `*📚 ORE BOOK* _(${found.length} ore)_\n\n`
    for (const [k, b] of Object.entries(biomes)) {
      const fl = b.listOre.filter((o) => found.includes(o.name.replace(/[\u{1F300}-\u{1F9FF}]/gu, '').trim()))
      if (fl.length > 0) {
        txt += `*${b.name}*\n`
        for (const o of fl) txt += `  ${rc(o.rarity)} ${o.name}\n`
        txt += '\n'
      }
    }
    return reply(ctx, txt.trim())
  }

  if (sub === 'travel') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (!subArgs[0]) {
      let txt = '*🗺️ DAFTAR BIOME*\n\n'
      for (const [k, b] of Object.entries(biomes)) {
        const req = travelRequirements[k]
        const ok = (mc.travelFound || []).includes(k)
        txt += `${ok ? '✅' : '🔒'} *${b.name}*${mc.currentBiome === k ? ' _< Now_' : ''}\n`
        txt += req ? `   _💰 ${formatMoney(req.money)} | 🧱 ${req.blocks} blocks_\n` : `   _🆓 Free_\n`
      }
      return reply(ctx, txt + '\n`.mct travel <biome>`')
    }
    const tk = subArgs[0].toLowerCase()
    if (!biomes[tk]) return reply(ctx, '_🗺️ Biome tidak ada!_ `.mct travel`')
    if (mc.currentBiome === tk) return reply(ctx, `_📍 Sudah di ${biomes[tk].name}!_`)
    const req = travelRequirements[tk]
    if (req) {
      if ((mc.money || 0) < req.money) return reply(ctx, `_💸 Uang kurang! Butuh ${formatMoney(req.money)}_`)
      if ((mc.blocksMined || 0) < req.blocks) return reply(ctx, `_🧱 Blocks kurang! Butuh ${req.blocks}_`)
      mc.money -= req.money
    }
    if (!(mc.travelFound || []).includes(tk)) mc.travelFound = [...(mc.travelFound || []), tk]
    mc.currentBiome = tk
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*🚪 PINDAH BIOME!*\n\n📍 Sekarang di *${biomes[tk].name}*\n🧱 ${biomes[tk].listOre.length} jenis ore tersedia`)
  }

  if (sub === 'shop') {
    let txt = '*🛒 TOKO PICKAXE*\n\n'
    for (const [k, pick] of Object.entries(pickaxes)) {
      if (pick.price > 0)
        txt += `*${pick.name}*\n   _💰 ${formatMoney(pick.price)}_\n   _🍀 Luck +${(pick.luck * 100).toFixed(0)}% | ⚡ Speed +${(pick.speed * 100).toFixed(0)}% | 📦 Combo: ${pick.comboOre}_\n   _${pick.description}_\n\n`
    }
    return reply(ctx, txt + '`.mct buy <pick>`')
  }

  if (sub === 'buy') {
    const mc = await loadMC(moduleData, sender, senderName)
    const pk = subArgs[0] ? subArgs[0].toLowerCase() : ''
    if (!pk) return reply(ctx, '_🪓 Tentukan pickaxe!_ `.mct shop`')
    if (!pickaxes[pk]) return reply(ctx, '_🪓 Pickaxe tidak ada!_ `.mct shop`')
    if (mc.pickaxes[pk]) return reply(ctx, `_✅ Sudah punya ${pickaxes[pk].name}!_`)
    if (pickaxes[pk].price === 0) return reply(ctx, '_🪙 Pickaxe ini dari Token/Prestige!_')
    if ((mc.money || 0) < pickaxes[pk].price) return reply(ctx, `_💸 Uang kurang! Butuh ${formatMoney(pickaxes[pk].price)}_`)
    mc.money -= pickaxes[pk].price
    mc.pickaxes[pk] = { ...pickaxes[pk] }
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*🛍️ PICKAXE DIBELI!*\n\n*${pickaxes[pk].name}*\n_🪓 Ketik_ \`.mct equip ${pk}\` _untuk memasang_`)
  }

  if (sub === 'equip') {
    const mc = await loadMC(moduleData, sender, senderName)
    const pk = subArgs[0] ? subArgs[0].toLowerCase() : ''
    if (!pk) return reply(ctx, '_🪓 Tentukan pickaxe!_ `.mct picks`')
    if (!mc.pickaxes[pk]) return reply(ctx, '_📭 Tidak punya pickaxe ini!_ `.mct picks`')
    mc.usedPickaxe = pk
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*🪓 PICKAXE DIPASANG!*\n\n*${mc.pickaxes[pk].name}* _✅ sekarang aktif_`)
  }

  if (sub === 'picks') {
    const mc = await loadMC(moduleData, sender, senderName)
    const pks = mc.pickaxes || {}
    if (Object.keys(pks).length === 0) return reply(ctx, '_📭 Tidak punya pickaxe!_')
    let txt = '*🎒 KOLEKSI PICKAXE*\n\n'
    for (const [k, pick] of Object.entries(pks)) {
      txt += `*${pick.name}*${mc.usedPickaxe === k ? ' _✅ AKTIF_' : ''}\n  _⬆️ Lv.${pick.level || 1}/${pick.maxLevel} | 🍀 Luck ${(pick.luck * 100).toFixed(0)}% | ⚡ Speed ${(pick.speed * 100).toFixed(0)}%_\n`
      if (pick.enchant)
        txt += `  _✨ Enchant: ${pickEnchants[pick.enchant] ? pickEnchants[pick.enchant].name : pick.enchant}_\n`
    }
    return reply(ctx, txt + '\n`.mct equip <pick>`')
  }

  if (sub === 'enchant') {
    const mc = await loadMC(moduleData, sender, senderName)
    const pk = mc.usedPickaxe || 'woodpick'
    const pick = mc.pickaxes[pk]
    if (!pick) return reply(ctx, '_🪓 Pickaxe aktif tidak ada!_')
    const ek = subArgs[0] ? subArgs[0].toLowerCase() : ''
    if (!ek) {
      if (pick.enchant) {
        const e = pickEnchants[pick.enchant]
        return reply(ctx, `_✨ Enchant saat ini: *${e ? e.name : pick.enchant}* (${e ? e.rarity : '?'})_\n\`.mct enchant <key>\` untuk ganti`)
      }
      return reply(ctx, '_✨ Tentukan enchant!_ `.mct enchants`')
    }
    if (!pickEnchants[ek]) return reply(ctx, '_✨ Enchant tidak ada!_ `.mct enchants`')
    const ench = pickEnchants[ek]
    const cost = encCost(ench.rarity)
    if ((mc.money || 0) < cost) return reply(ctx, `_💸 Uang kurang! Butuh ${formatMoney(cost)}_`)
    mc.money -= cost
    pick.enchant = ek
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*✨ ENCHANT DIPASANG!*\n\n*${ench.name}* _(${ench.rarity})_ ke *${pick.name}*\n_${ench.desc}_\n_💰 Biaya: ${formatMoney(cost)}_`)
  }

  if (sub === 'enchants') {
    const byR = {}
    for (const [k, e] of Object.entries(pickEnchants)) {
      if (!byR[e.rarity]) byR[e.rarity] = []
      byR[e.rarity].push({ key: k, name: e.name, desc: e.desc })
    }
    let txt = '*📜 DAFTAR ENCHANTMENT*\n\n'
    for (const r of ['common', 'rare', 'epic', 'legendary', 'mythic', 'godly', 'secret']) {
      const list = byR[r]
      if (!list) continue
      txt += `${rc(r)} *${r.toUpperCase()}* _${formatMoney(encCost(r))}_\n`
      for (const e of list) txt += `  \`${e.key}\`: ${e.name} _${e.desc}_\n`
      txt += '\n'
    }
    return reply(ctx, txt.trim() + '\n`.mct enchant <key>`')
  }

  if (sub === 'pickup') {
    const mc = await loadMC(moduleData, sender, senderName)
    const pk = mc.usedPickaxe || 'woodpick'
    const pick = mc.pickaxes[pk]
    if (!pick) return reply(ctx, '_🪓 Pickaxe aktif tidak ada!_')
    if (pick.level >= pick.maxLevel) return reply(ctx, '_⬆️ Pickaxe sudah max level!_')
    const cost = Math.floor(pick.price * 0.1 * pick.level) || 12000 * pick.level
    if ((mc.money || 0) < cost) return reply(ctx, `_💸 Uang kurang! Butuh ${formatMoney(cost)}_`)
    mc.money -= cost
    const res = addPickExp(mc, pk, Math.floor(pick.expToNextLevel * 0.5))
    await saveMC(moduleData, sender, mc)
    return reply(ctx, res
      ? `*⬆️ PICKAXE UPGRADED!*\n\n${res}\n_💰 Biaya: ${formatMoney(cost)}_`
      : `*⭐ PICKAXE EXP UP!*\n\n⭐ +${Math.floor(pick.expToNextLevel * 0.5)} EXP\n_💰 Biaya: ${formatMoney(cost)}_`)
  }

  if (sub === 'fight') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (!subArgs[0]) {
      const mobs = getAvailableMobs(mc)
      if (mobs.length === 0) return reply(ctx, '_👹 Tidak ada mob tersedia! Naikkan level dulu._')
      let txt = `*👹 DAFTAR MOB*\n\n_❤️ HP: ${mc.hp}/${mc.maxHp} | ⚔️ ATK: ${mc.atk}_\n\n`
      for (const mob of mobs) {
        txt += `${rc(mob.rarity)} *${mob.name}*\n  _❤️ HP: ${mob.hp} | ⚔️ ATK: ${mob.atk} | ⬆️ Lv.${mob.minLevel}+_  \n`
      }
      txt += '\n`.mct fight <mob>` untuk ⚔️ menyerang!'
      return reply(ctx, txt)
    }
    const mk = subArgs[0].toLowerCase()
    if (!mobData[mk]) return reply(ctx, '_👹 Mob tidak ada!_ `.mct fight`')
    const result = doCombat(mc, mk)
    if (result.error) return reply(ctx, `_${result.error}_`)
    await saveMC(moduleData, sender, mc)
    if (result.won) {
      let txt = `*🏆 KAMU MENANG!*\n\n⚔️ Melawan *${result.mobName}*\n\n`
      for (const line of result.log) txt += `${line}\n`
      txt += `\n*⭐ EXP:* +${result.expGain}`
      if (result.drops.length > 0) {
        txt += '\n*🎁 Drops:*'
        for (const d of result.drops)
          txt += `\n  ${d.name} _💰 ${formatMoney(d.value)}_`
      }
      return reply(ctx, txt)
    } else {
      let txt = `*💀 KAMU KALAH!*\n\n⚔️ Melawan *${result.mobName}*\n\n`
      for (const line of result.log) txt += `${line}\n`
      txt += `\n_❤️ HP tersisa: ${mc.hp}/${mc.maxHp}_\n\`.mct heal\` untuk ❤️ sembuh`
      return reply(ctx, txt)
    }
  }

  if (sub === 'heal') {
    const mc = await loadMC(moduleData, sender, senderName)
    const result = healPlayer(mc)
    if (result.error) return reply(ctx, `_${result.error}_`)
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*❤️ HEAL!*\n\n❤️ HP: ${result.hp}/${mc.maxHp}\n_💰 Biaya: ${formatMoney(result.cost)}_`)
  }

  if (sub === 'smelt') {
    const mc = await loadMC(moduleData, sender, senderName)
    const result = doSmelt(mc)
    if (result.count === 0) return reply(ctx, '_🔥 Tidak ada ore yang bisa di-smelt!_')
    mc.money = (mc.money || 0) + result.totalValue
    mc.totalEarned = (mc.totalEarned || 0) + result.totalValue
    let txt = '*🔥 SMELTING SELESAI!*\n\n'
    for (const s of result.smelted)
      txt += `${s.from} → ${s.to} _💰 ${formatMoney(s.value)}_\n`
    txt += `\n*💰 Total: ${formatMoney(result.totalValue)}*\n*🏦 Saldo: ${formatMoney(mc.money)}*`
    await saveMC(moduleData, sender, mc)
    return reply(ctx, txt)
  }

  if (sub === 'craft') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (!subArgs[0]) {
      let txt = '*🛠️ DAFTAR CRAFTING*\n\n'
      for (const [k, r] of Object.entries(CRAFT_RECIPES)) {
        const canCraft = (mc.level || 1) >= r.requiredLevel
        txt += `${canCraft ? '✅' : '🔒'} *${r.name}* _\`${k}\`_\n  _💰 Value: ${formatMoney(r.value)} | ⬆️ Lv.${r.requiredLevel}+_\n  _🧪 Bahan:_\n`
        for (const [ing, cnt] of Object.entries(r.ingredients))
          txt += `    _${ing} x${cnt}_\n`
        txt += '\n'
      }
      return reply(ctx, txt + '`.mct craft <id>`')
    }
    const result = doCraft(mc, subArgs[0].toLowerCase())
    if (result.error) return reply(ctx, `_${result.error}_`)
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*🛠️ CRAFTING BERHASIL!*\n\n*${result.item}*\n_💰 Value: ${formatMoney(result.value)}_`)
  }

  if (sub === 'inv' || sub === 'inventory') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (!mc.inventory || mc.inventory.length === 0) return reply(ctx, '_🎒 Inventory kosong!_')
    const grouped = {}
    for (const item of mc.inventory) {
      const key = item.name
      if (!grouped[key]) grouped[key] = { name: item.name, count: 0, value: 0 }
      grouped[key].count++
      grouped[key].value += item.price || 0
    }
    let txt = '*🎒 INVENTORY*\n\n'
    let totalV = 0
    for (const g of Object.values(grouped)) {
      txt += `${g.name} _📦 x${g.count} | 💰 ${formatMoney(g.value)}_\n`
      totalV += g.value
    }
    txt += `\n*💰 Total Value: ${formatMoney(totalV)}*`
    return reply(ctx, txt)
  }

  if (sub === 'daily') {
    const mc = await loadMC(moduleData, sender, senderName)
    const now = new Date()
    if (mc.lastDaily) {
      const diff = now.getTime() - new Date(mc.lastDaily).getTime()
      if (diff < 86400000)
        return reply(ctx, `_🎁 Daily sudah diambil! Tunggu *${Math.ceil((86400000 - diff) / 3600000)}* jam._`)
    }
    const ld = mc.lastDaily ? new Date(mc.lastDaily) : null
    mc.dailyStreak = ld && now.getTime() - ld.getTime() < 172800000 ? (mc.dailyStreak || 0) + 1 : 1
    let rw = DAILY_REWARDS[0]
    for (const r of DAILY_REWARDS) {
      if (mc.dailyStreak >= r.streak) rw = r
    }
    mc.money = (mc.money || 0) + rw.money
    mc.gachaTickets = (mc.gachaTickets || 0) + rw.tickets
    mc.lastDaily = now.toISOString()
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*🎁 DAILY REWARD!*\n\n*🔥 Streak:* ${mc.dailyStreak} hari\n💰 +${formatMoney(rw.money)}\n🎟️ +${rw.tickets} Tiket Gacha\n*🏦 Saldo:* ${formatMoney(mc.money)}`)
  }

  if (sub === 'gacha') {
    const mc = await loadMC(moduleData, sender, senderName)
    const useT = subArgs[0] && subArgs[0].toLowerCase() === 'ticket'
    if (useT) {
      if ((mc.gachaTickets || 0) < 1) return reply(ctx, `_🎟️ Tiket habis! Punya ${mc.gachaTickets || 0}_`)
      mc.gachaTickets -= 1
    } else {
      if ((mc.money || 0) < GACHA_COST_COINS) return reply(ctx, `_💸 Uang kurang! Butuh ${formatMoney(GACHA_COST_COINS)}_`)
      mc.money -= GACHA_COST_COINS
    }
    const result = doGachaPull(mc)
    const item = result.item
    let txt = '*🎰 GACHA RESULT!*\n\n'
    switch (item.type) {
      case 'pickaxe':
        if (pickaxes[item.value] && !mc.pickaxes[item.value]) {
          mc.pickaxes[item.value] = { ...pickaxes[item.value] }
          txt += `🪓 DAPAT PICKAXE: *${item.label}*\n`
        } else if (mc.pickaxes[item.value]) {
          const ref = Math.floor((pickaxes[item.value] ? pickaxes[item.value].price : 0) * 0.3 || 120000)
          mc.money = (mc.money || 0) + ref
          txt += `♻️ Duplikat: *${item.label}* _💰 +${formatMoney(ref)}_\n`
        }
        break
      case 'tickets':
        mc.gachaTickets = (mc.gachaTickets || 0) + item.value
        txt += `🎟️ +${item.value} Tiket\n`
        break
      case 'tokens':
        mc.prestigeTokens = (mc.prestigeTokens || 0) + item.value
        txt += `🪙 +${item.value} Tokens\n`
        break
      case 'coins':
        mc.money = (mc.money || 0) + item.value
        txt += `💰 +${formatMoney(item.value)}\n`
        break
      case 'enchant_scroll': {
        const avail = Object.entries(pickEnchants).filter(([, v]) => v.rarity === item.value)
        if (avail.length > 0) {
          const [ek2, ed] = avail[Math.floor(Math.random() * avail.length)]
          const pk2 = mc.usedPickaxe || 'woodpick'
          if (mc.pickaxes[pk2]) {
            mc.pickaxes[pk2].enchant = ek2
            txt += `✨ Enchant: *${ed.name}* _(${item.value})_ ke pickaxe!\n`
          }
        }
        break
      }
      case 'xp_boost':
        mc.exp = (mc.exp || 0) + Math.floor(mc.expToNextLevel * 0.5)
        txt += `⭐ XP Boost x${item.value}!\n`
        break
      default:
        txt += `${item.label}\n`
    }
    if (result.isSSR) txt += '\n*🌈 SSR PULL!*'
    if (result.pity) txt += '\n*🔥 Pity Activated!*'
    txt += `\n\n_🔥 Pity: ${mc.gachaPity}/${GACHA_PITY_LIMIT}_\n_🏦 Saldo: ${formatMoney(mc.money)} | 🎟️ Tiket: ${mc.gachaTickets}_`
    await saveMC(moduleData, sender, mc)
    return reply(ctx, txt)
  }

  if (sub === 'upgrade') {
    const mc = await loadMC(moduleData, sender, senderName)
    const type = subArgs[0] ? subArgs[0].toLowerCase() : ''
    if (!type || !UPGRADES[type]) {
      let txt = '*📈 UPGRADE SHOP*\n\n'
      for (const [k, u] of Object.entries(UPGRADES)) {
        const lv = mc[k + 'Upgrade'] || 0
        txt += `*${u.name}* _(Lv.${lv}/${u.maxLevel})_\n  _${u.desc}_\n  ${lv >= u.maxLevel ? '_✅ MAXED_' : `_💰 Next: ${formatMoney(u.getCost(lv))}_`}\n\n`
      }
      return reply(ctx, txt + '\n`.mct upgrade <luck/speed/fortune/combat>`')
    }
    const upg = UPGRADES[type]
    const lv = mc[type + 'Upgrade'] || 0
    if (lv >= upg.maxLevel) return reply(ctx, '_✅ Sudah max!_')
    const cost = upg.getCost(lv)
    if ((mc.money || 0) < cost) return reply(ctx, `_💸 Uang kurang! Butuh ${formatMoney(cost)}_`)
    mc.money -= cost
    mc[type + 'Upgrade'] = lv + 1
    if (type === 'combat') mc.atk = 4 + Math.floor(mc.level * 0.5) + (lv + 1) * 3
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*⬆️ ${upg.name} LEVEL UP!*\n\n_⬆️ Level ${lv + 1}_\n_💰 Biaya: ${formatMoney(cost)}_\n_${upg.desc}_`)
  }

  if (sub === 'prestige') {
    const mc = await loadMC(moduleData, sender, senderName)
    const cp = mc.prestige || 0
    if (subArgs[0] && subArgs[0].toLowerCase() === 'confirm') {
      const reqs = [
        { blocks: 500, money: 2e10 },
        { blocks: 1500, money: 2e12 },
        { blocks: 4000, money: 2e14 },
        { blocks: 10000, money: 2e19 },
        { blocks: 25000, money: 2e22 },
      ]
      const req = reqs[cp]
      if (!req) return reply(ctx, '_👑 Sudah max prestige!_')
      if ((mc.blocksMined || 0) < req.blocks) return reply(ctx, `_🧱 Blocks kurang! Butuh ${req.blocks}_`)
      if ((mc.money || 0) < req.money) return reply(ctx, `_💸 Uang kurang! Butuh ${formatMoney(req.money)}_`)
      mc.prestige = cp + 1
      mc.money = Math.floor(mc.money * 0.1)
      mc.blocksMined = 0
      mc.streak = 0
      mc.prestigeTokens = (mc.prestigeTokens || 0) + [60, 180, 600, 1200, 6000][cp]
      const titles = ['Penambang Baru', 'Veteran', 'Master Miner', 'Legend', 'Transcendent', 'God of Mining']
      if (cp === 0 && !mc.pickaxes.prestigepick) mc.pickaxes.prestigepick = { ...pickaxes.prestigepick }
      if (cp === 2 && !mc.pickaxes.cosmicpick) mc.pickaxes.cosmicpick = { ...pickaxes.cosmicpick }
      await saveMC(moduleData, sender, mc)
      return reply(ctx, `*👑 PRESTIGE UP!*\n\n*🏷️ Title:* ${titles[mc.prestige]}\n*🪙 Tokens:* ${mc.prestigeTokens}\n\n_💸 Uang -90%, 🧱 blocks count reset_`)
    }
    let txt = `*👑 PRESTIGE SYSTEM*\n\n*👑 Prestige:* ${cp}\n*🪙 Tokens:* ${mc.prestigeTokens || 0}\n\n`
    const allReqs = [
      { lv: 1, blocks: 500, money: 2e10, rw: 'Prestige Pickaxe + 60 tokens' },
      { lv: 2, blocks: 1500, money: 2e12, rw: 'Luck +20% + 180 tokens' },
      { lv: 3, blocks: 4000, money: 2e14, rw: 'Cosmic Pickaxe + 600 tokens' },
      { lv: 4, blocks: 10000, money: 2e19, rw: '2x EXP + 1200 tokens' },
      { lv: 5, blocks: 25000, money: 2e22, rw: 'Omega Pickaxe + 6000 tokens' },
    ]
    for (const r of allReqs)
      txt += `${cp >= r.lv ? '✅' : '🔒'} *P${r.lv}*: _🧱 ${r.blocks} blocks | 💰 ${formatMoney(r.money)}_\n  _${r.rw}_\n\n`
    return reply(ctx, txt + '\n`.mct prestige confirm` _(hati-hati!)_')
  }

  if (sub === 'tokens') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (!subArgs[0]) {
      let txt = `*🪙 TOKEN STORE*\n\n*🪙 Tokens:* ${mc.prestigeTokens || 0}\n\n`
      for (const item of TOKEN_SHOP)
        txt += `*${item.name}* _🪙 ${item.cost} tokens_\n`
      return reply(ctx, txt + '\n`.mct tokens <id>`')
    }
    const iid = subArgs[0].toLowerCase()
    const item = TOKEN_SHOP.find((i) => i.id === iid)
    if (!item) return reply(ctx, '_🛒 Item tidak ada!_ `.mct tokens`')
    if ((mc.prestigeTokens || 0) < item.cost) return reply(ctx, `_🪙 Tokens kurang! Butuh ${item.cost}_`)
    mc.prestigeTokens -= item.cost
    switch (item.type) {
      case 'pickaxe':
        if (pickaxes[item.value] && !mc.pickaxes[item.value]) {
          mc.pickaxes[item.value] = { ...pickaxes[item.value] }
        } else {
          mc.prestigeTokens += item.cost
          return reply(ctx, '_✅ Sudah punya pickaxe ini!_')
        }
        break
      case 'tickets':
        mc.gachaTickets = (mc.gachaTickets || 0) + item.value
        break
      case 'coins':
        mc.money = (mc.money || 0) + item.value
        break
    }
    await saveMC(moduleData, sender, mc)
    return reply(ctx, `*🛍️ ITEM DIBELI!*\n\n*${item.name}* _seharga 🪙 ${item.cost} tokens_`)
  }

  if (sub === 'jackpot') {
    const mc = await loadMC(moduleData, sender, senderName)
    if (!subArgs[0]) {
      let txt = `*🎰 JACKPOT SYSTEM*\n\n_💎 Sistem jackpot dengan hadiah super besar!_\n_🎁 Hadiah energi/limit/premium dikonversi ke koin!_\n\n`
      for (const pool of JACKPOT_POOLS) {
        txt += `*${pool.name}*\n  _💰 Biaya: ${formatMoney(pool.cost)}_\n  _🎯 Rate: ${pool.weight}%_\n  _🎁 Rewards:_\n`
        for (const rw of pool.rewards) {
          txt += `    _${jackpotLabel(rw.type)}: ${rw.min === rw.max ? rw.min : `${rw.min}-${rw.max}`} (${rw.weight}%)_\n`
        }
        txt += '\n'
      }
      return reply(ctx, txt + '`.mct jackpot <iron/gold/diamond/netherite/dragon>`')
    }
    const poolId = subArgs[0].toLowerCase()
    const pool = JACKPOT_POOLS.find((p) => p.id === poolId)
    if (!pool) return reply(ctx, '_🎰 Tier tidak ada!_ `.mct jackpot`')
    if ((mc.money || 0) < pool.cost) return reply(ctx, `_💸 Uang kurang! Butuh ${formatMoney(pool.cost)}_`)
    mc.money -= pool.cost
    const result = doJackpotPull(mc, poolId)
    if (!result) return reply(ctx, '_❌ Gagal! Coba lagi._')
    const applied = await applyJackpotReward(mc, result)
    await saveMC(moduleData, sender, mc)
    const isBig = ['premium_7d', 'premium_30d', 'partner_7d', 'partner_30d', 'unlimited_energi', 'unlimited_limit', 'owner_reward'].includes(result.reward.type)
    let txt = `*🎰 ${pool.name.toUpperCase()}!*\n\n`
    if (isBig) txt += '*💥 JACKPOT BESAR!*\n\n'
    txt += `${applied.desc}\n\n_💰 Biaya: ${formatMoney(pool.cost)}_\n_🏦 Saldo: ${formatMoney(mc.money)}_`
    return reply(ctx, txt)
  }

  if (sub === 'top') {
    const rows = await moduleData.getAllByKey('user', 'mc')
    const rankings = []
    for (const row of rows) {
      const ud = row.value || {}
      if (ud && (ud.blocksMined || ud.money)) {
        rankings.push({ jid: row.entityId, name: ud.name, blocksMined: ud.blocksMined || 0, money: ud.money || 0, level: ud.level || 1, prestige: ud.prestige || 0 })
      }
    }
    if (rankings.length === 0) return reply(ctx, '_👤 Belum ada pemain!_')
    rankings.sort((a, b) => {
      if (b.prestige !== a.prestige) return b.prestige - a.prestige
      if (b.blocksMined !== a.blocksMined) return b.blocksMined - a.blocksMined
      return b.money - a.money
    })
    let txt = '*🏆 LEADERBOARD MINECRAFT*\n\n'
    const top = rankings.slice(0, 10)
    for (let i = 0; i < top.length; i++) {
      const p = top[i]
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`
      // Nama sudah tersimpan di record user. Record lama (yang dibuat sebelum
      // pushName ikut disimpan) jatuh ke nomor HP.
      txt += `${medal} @${p.name || p.jid.split('@')[0]}\n  _👑 P${p.prestige} | 🧱 ${p.blocksMined} blocks | 💰 ${formatMoney(p.money)}_\n`
    }
    return reply(ctx, txt.trim())
  }

  return reply(ctx, '_Sub-command tidak dikenal!_ Ketik `.mct help`')
}

export default {
  name: 'minecraft',
  command: ['mct', 'minecraft'],
  allow: CHAT.BOTH,
  role: 10,
  category: 'game',
  description: 'Minecraft - Mining & Crafting Game',
  handle: handler,
}