export default {
  id: 'minecraft',
  name: 'Minecraft',
  description: 'Minecraft - Mining & Crafting Game',
  enabled: true,
  commands: ['mct', 'minecraft'],
  events: [],
}